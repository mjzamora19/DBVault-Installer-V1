/* Query Editor - works inside TabManager tabs */

var QueryEditor = {
    editors: {},   // tabId -> CodeMirror instance
    databases: {}, // tabId -> selected database
    connIds: {},   // tabId -> connection id
    connId: null,

    openTab: function(connId, database, sql) {
        this.connId = connId;
        var db = database || App.state.activeDatabase || '';
        var title = sql ? sql.substring(0, 30).replace(/\n/g,' ') + '...' : 'New Query';
        var self = this;

        TabManager.addTab(title, 'ti-file-text', 'query', function(panel, tabId) {
            self.connIds[tabId] = connId;
            self.databases[tabId] = db;
            panel.innerHTML = '' +
                '<div class="query-toolbar">' +
                    '<label style="font-size:12px;color:var(--fg2)">Database:</label>' +
                    '<select id="qdb-' + tabId + '" onchange="QueryEditor.databases[\'' + tabId + '\']=this.value;App.state.activeDatabase=this.value"></select>' +
                    '<div style="flex:1"></div>' +
                    '<button class="btn btn-primary btn-sm" onclick="QueryEditor.execute(\'' + tabId + '\')"><i class="ti ti-player-play"></i> Execute</button>' +
                    '<button class="btn btn-sm" onclick="QueryEditor.doExport(\'' + tabId + '\',\'csv\')"><i class="ti ti-download"></i> CSV</button>' +
                    '<button class="btn btn-sm" onclick="QueryEditor.doExport(\'' + tabId + '\',\'json\')"><i class="ti ti-download"></i> JSON</button>' +
                '</div>' +
                '<div style="flex:1;display:flex;flex-direction:column;overflow:hidden">' +
                    '<div class="query-editor-panel" id="qeditor-' + tabId + '">' +
                        '<textarea id="qtextarea-' + tabId + '"></textarea>' +
                    '</div>' +
                    '<div class="split-handle" id="qsplit-' + tabId + '"></div>' +
                    '<div class="query-results-panel" id="qresults-' + tabId + '">' +
                        '<div class="query-results-header">' +
                            '<span class="result-info" id="qinfo-' + tabId + '">Ctrl+Enter = Execute &bull; Ctrl+R = Toggle Results</span>' +
                        '</div>' +
                        '<div class="data-grid-wrapper" id="qgrid-' + tabId + '">' +
                            '<div class="empty-state" style="height:100%"><p>Results will appear here</p></div>' +
                        '</div>' +
                    '</div>' +
                '</div>';

            self.loadDbSelector(tabId, db);
            self.initEditor(tabId, sql || '');
            self.initSplitter(tabId);
        });

        // Return last tab id for auto-execute
        return 'tab-' + (TabManager.nextId - 1);
    },

    loadDbSelector: function(tabId, selectedDb) {
        var self = this;
        var select = document.getElementById('qdb-' + tabId);
        var cid = self.connIds[tabId] || self.connId;
        if (!select || !cid) return;
        API.getDatabases(cid).then(function(data) {
            select.innerHTML = '<option value="">-- Select Database --</option>';
            (data.databases || []).forEach(function(db) {
                var opt = document.createElement('option');
                opt.value = db; opt.textContent = db;
                if (db === selectedDb) opt.selected = true;
                select.appendChild(opt);
            });
            // Only auto-select if a specific db was passed
            if (selectedDb) {
                self.databases[tabId] = selectedDb;
            }
        }).catch(function(e) {
            select.innerHTML = '<option>Error loading</option>';
        });
    },

    initEditor: function(tabId, sql) {
        var self = this;
        var textarea = document.getElementById('qtextarea-' + tabId);
        if (!textarea) return;

        if (typeof CodeMirror === 'undefined') {
            textarea.style.cssText = 'width:100%;height:100%;background:var(--bg0);color:var(--fg);border:none;padding:16px;font-family:JetBrains Mono,monospace;font-size:14px;resize:none;outline:none;';
            textarea.value = sql || '';
            textarea.addEventListener('keydown', function(e) {
                if (e.ctrlKey && e.key === 'Enter') { e.preventDefault(); self.execute(tabId); }
                if (e.ctrlKey && e.key.toLowerCase() === 'r') { e.preventDefault(); self.toggleResults(tabId); }
            });
            return;
        }

        // Store autocomplete data per tab
        self.tableData = self.tableData || {};
        self.tableData[tabId] = {};

        var editor = CodeMirror.fromTextArea(textarea, {
            mode: 'text/x-mssql',
            theme: 'dracula',
            lineNumbers: true,
            matchBrackets: true,
            indentUnit: 4,
            tabSize: 4,
            lineWrapping: true,
            extraKeys: {
                'Ctrl-Enter': function() { self.execute(tabId); },
                'Ctrl-R': function() { self.toggleResults(tabId); },
                'Ctrl-Space': function(cm) { self.showHint(cm, tabId); }
            }
        });

        // Auto-show hints as user types
        editor.on('inputRead', function(cm, change) {
            if (change.text[0] && change.text[0].match(/\w/) && cm.getCursor().ch > 1) {
                clearTimeout(self._hintTimer);
                self._hintTimer = setTimeout(function() { self.showHint(cm, tabId); }, 300);
            }
        });

        editor.setValue(sql || '');
        self.editors[tabId] = editor;

        // Load table/column names for autocomplete
        self.loadAutocomplete(tabId);

        setTimeout(function() { editor.refresh(); editor.focus(); }, 100);
    },

    initSplitter: function(tabId) {
        var self = this;
        var handle = document.getElementById('qsplit-' + tabId);
        if (!handle) return;
        var editorPanel = document.getElementById('qeditor-' + tabId);

        handle.addEventListener('mousedown', function(e) {
            var startY = e.clientY;
            var startH = editorPanel.offsetHeight;
            var onMove = function(ev) {
                editorPanel.style.flex = 'none';
                editorPanel.style.height = Math.max(80, startH + (ev.clientY - startY)) + 'px';
                if (self.editors[tabId]) self.editors[tabId].refresh();
            };
            var onUp = function() {
                document.removeEventListener('mousemove', onMove);
                document.removeEventListener('mouseup', onUp);
            };
            document.addEventListener('mousemove', onMove);
            document.addEventListener('mouseup', onUp);
        });
    },

    execute: function(tabId) {
        var self = this;
        var editor = this.editors[tabId];
        var sql = editor ? editor.getValue() : '';
        if (!sql) {
            var ta = document.getElementById('qtextarea-' + tabId);
            if (ta) sql = ta.value;
        }
        if (!sql || !sql.trim()) { Toast.warning('Enter a SQL query'); return; }

        // Handle GO batch separator like SSMS - split into batches
        var batches = sql.split(/^\s*GO\s*$/mi).filter(function(b) { return b.trim(); });

        // Handle USE database command - update dropdown and global state
        var useMatch = sql.match(/^\s*USE\s+\[?(\w+)\]?\s*;?\s*$/mi);
        if (useMatch) {
            var newDb = useMatch[1];
            self.databases[tabId] = newDb;
            App.state.activeDatabase = newDb;
            var select = document.getElementById('qdb-' + tabId);
            if (select) select.value = newDb;
        }

        // Execute last meaningful batch (or all if just one)
        var execSql = batches.length > 0 ? batches[batches.length - 1].trim() : sql;
        // If it's just USE, execute it but show success
        if (execSql.match(/^\s*USE\s+/i) && batches.length <= 1) {
            execSql = 'SELECT DB_NAME() AS [Current Database]';
        }

        var info = document.getElementById('qinfo-' + tabId);
        info.innerHTML = '<i class="ti ti-loader-2" style="animation:spin 1s linear infinite"></i> Executing...';
        var db = this.databases[tabId] || '';
        var cid = this.connIds[tabId] || this.connId;

        if (!cid) {
            info.innerHTML = '<span style="color:var(--red)">No connection. Connect to a database first.</span>';
            return;
        }

        API.executeQuery(cid, execSql, db).then(function(result) {
            info.innerHTML = '<strong>' + (result.total_rows || 0).toLocaleString() + '</strong> rows &bull; <strong>' + result.execution_time_ms + '</strong>ms' +
                (result.affected_rows !== null && result.affected_rows !== undefined ? ' &bull; <strong>' + result.affected_rows + '</strong> affected' : '');

            App.updateRowCount(result.total_rows);
            App.updateExecTime(result.execution_time_ms);

            if (result.columns && result.columns.length && result.rows && result.rows.length) {
                self.renderGrid(tabId, result);
            } else {
                var msg = 'Query executed successfully';
                if (result.affected_rows > 0) msg = result.affected_rows + ' row(s) affected';
                if (result.messages && result.messages.length) msg = result.messages.join('<br>');
                document.getElementById('qgrid-' + tabId).innerHTML = '<div class="empty-state" style="height:100%"><h3 style="color:var(--green)"><i class="ti ti-check"></i> ' + msg + '</h3></div>';
            }
        }).catch(function(e) {
            info.innerHTML = '<span style="color:var(--red)"><i class="ti ti-alert-circle"></i> ' + esc(e.message) + '</span>';
        });
    },

    renderGrid: function(tabId, result) {
        var container = document.getElementById('qgrid-' + tabId);
        container.innerHTML = '';
        container.className = 'data-grid-wrapper';

        var scrollWrap = document.createElement('div');
        scrollWrap.style.cssText = 'flex:1;overflow:auto;';

        var table = document.createElement('table');
        table.style.cssText = 'border-collapse:collapse;width:max-content;min-width:100%;';

        // Header
        var thead = document.createElement('thead');
        var headerRow = document.createElement('tr');
        headerRow.innerHTML = '<th style="padding:6px 8px;background:var(--bg2);border:1px solid var(--border);color:var(--fg2);font-size:10px;text-transform:uppercase;position:sticky;top:0;z-index:1">#</th>';
        result.columns.forEach(function(col) {
            headerRow.innerHTML += '<th style="padding:6px 10px;background:var(--bg2);border:1px solid var(--border);color:var(--accent-light);font-size:11px;font-weight:600;white-space:nowrap;position:sticky;top:0;z-index:1">' + esc(col.name) + ' <span style="color:var(--fg3);font-weight:400;font-size:9px">' + col.type + '</span></th>';
        });
        thead.appendChild(headerRow);
        table.appendChild(thead);

        // Body
        var tbody = document.createElement('tbody');
        result.rows.forEach(function(row, idx) {
            var tr = document.createElement('tr');
            tr.innerHTML = '<td style="padding:4px 8px;border:1px solid var(--border);color:var(--fg3);font-size:10px;text-align:center;background:var(--bg1)">' + (result.offset + idx + 1) + '</td>';
            row.forEach(function(val) {
                if (val === null) {
                    tr.innerHTML += '<td style="padding:4px 10px;border:1px solid var(--border);color:var(--fg3);font-style:italic;font-size:12px;font-family:JetBrains Mono,monospace">NULL</td>';
                } else {
                    tr.innerHTML += '<td style="padding:4px 10px;border:1px solid var(--border);color:var(--fg);font-size:12px;font-family:JetBrains Mono,monospace;white-space:nowrap">' + esc(String(val)) + '</td>';
                }
            });
            tbody.appendChild(tr);
        });
        table.appendChild(tbody);

        scrollWrap.appendChild(table);
        container.appendChild(scrollWrap);

        // Pagination
        if (result.total_rows > result.limit) {
            var footer = document.createElement('div');
            footer.className = 'data-grid-footer';
            var page = Math.floor(result.offset / result.limit) + 1;
            var totalPages = Math.ceil(result.total_rows / result.limit);
            footer.innerHTML = '<div class="page-info">Showing ' + (result.offset + 1) + '-' + Math.min(result.offset + result.limit, result.total_rows) + ' of ' + result.total_rows.toLocaleString() + '</div>' +
                '<div class="page-nav">' +
                '<button class="btn btn-sm" ' + (page<=1?'disabled':'') + ' onclick="QueryEditor.paginate(\'' + tabId + '\',0)">First</button>' +
                '<button class="btn btn-sm" ' + (page<=1?'disabled':'') + ' onclick="QueryEditor.paginate(\'' + tabId + '\',' + (result.offset-result.limit) + ')">Prev</button>' +
                '<span style="padding:4px 8px;color:var(--fg3)">' + page + ' / ' + totalPages + '</span>' +
                '<button class="btn btn-sm" ' + (page>=totalPages?'disabled':'') + ' onclick="QueryEditor.paginate(\'' + tabId + '\',' + (result.offset+result.limit) + ')">Next</button>' +
                '<button class="btn btn-sm" ' + (page>=totalPages?'disabled':'') + ' onclick="QueryEditor.paginate(\'' + tabId + '\',' + ((totalPages-1)*result.limit) + ')">Last</button>' +
                '</div>';
            container.appendChild(footer);
        }
    },

    paginate: function(tabId, offset) {
        var self = this;
        var editor = this.editors[tabId];
        var sql = editor ? editor.getValue() : '';
        if (!sql) return;
        var db = this.databases[tabId] || '';
        var cid = this.connIds[tabId] || this.connId;
        API.executeQuery(cid, sql, db, Math.max(0, offset)).then(function(result) {
            document.getElementById('qinfo-' + tabId).innerHTML = '<strong>' + (result.total_rows||0).toLocaleString() + '</strong> rows &bull; <strong>' + result.execution_time_ms + '</strong>ms';
            if (result.columns && result.columns.length) self.renderGrid(tabId, result);
        }).catch(function(e) { Toast.error(e.message); });
    },

    showHint: function(cm, tabId) {
        var self = this;
        var cur = cm.getCursor();
        var line = cm.getLine(cur.line);
        var end = cur.ch;
        var start = end;

        while (start > 0 && /[\w.\[\]]/.test(line.charAt(start - 1))) start--;
        var raw = line.substring(start, end);
        var word = raw.replace(/[\[\]]/g, '').toLowerCase();

        if (word.length < 1) return;

        var tables = self.tableData[tabId] || {};
        var ac = self.acData[tabId] || { databases:[], schemas:[], views:[], procs:[], funcs:[] };
        var list = [];
        var parts = word.split('.');
        var dotCount = parts.length - 1;
        var lastPart = parts[parts.length - 1];

        var KW = ['SELECT','FROM','WHERE','INSERT','INTO','UPDATE','SET','VALUES',
            'AND','OR','NOT','IN','LIKE','BETWEEN','IS','NULL','EXISTS',
            'JOIN','INNER','LEFT','RIGHT','OUTER','FULL','CROSS','ON','AS',
            'ORDER','BY','ASC','DESC','GROUP','HAVING','TOP','DISTINCT',
            'UNION','ALL','EXCEPT','INTERSECT',
            'CASE','WHEN','THEN','ELSE','END',
            'BEGIN','COMMIT','ROLLBACK','TRANSACTION','TRY','CATCH',
            'DECLARE','SET','PRINT','EXEC','EXECUTE','USE','GO',
            'CREATE','TABLE','VIEW','PROCEDURE','FUNCTION','TRIGGER','INDEX','SCHEMA','DATABASE',
            'IF','WHILE','RETURN','THROW','RAISERROR',
            'VARCHAR','NVARCHAR','INT','BIGINT','SMALLINT','TINYINT','BIT',
            'DATETIME','DATETIME2','DATE','TIME','FLOAT','DECIMAL','NUMERIC','MONEY',
            'CHAR','NCHAR','TEXT','NTEXT','XML','UNIQUEIDENTIFIER','VARBINARY',
            'PRIMARY','KEY','FOREIGN','REFERENCES','CONSTRAINT','DEFAULT','IDENTITY','NOT',
            'COUNT','SUM','AVG','MAX','MIN','LEN','UPPER','LOWER','TRIM','LTRIM','RTRIM',
            'SUBSTRING','REPLACE','CHARINDEX','CONVERT','CAST','ISNULL','COALESCE',
            'GETDATE','GETUTCDATE','DATEADD','DATEDIFF','DATEPART','YEAR','MONTH','DAY',
            'NEWID','ROW_NUMBER','RANK','DENSE_RANK','OVER','PARTITION',
            'STRING_AGG','STUFF','FORMAT','TRY_CAST','TRY_CONVERT','IIF',
            'SCOPE_IDENTITY','@@ROWCOUNT','@@IDENTITY','DB_NAME','OBJECT_ID'];

        function match(name, prefix) {
            return name.toLowerCase().indexOf(prefix.toLowerCase()) === 0;
        }
        function bracket(name) { return '[' + name + ']'; }

        if (dotCount === 0) {
            // No dot: suggest databases, schemas, tables, views, procs, funcs, columns, keywords
            // Databases
            ac.databases.forEach(function(db) {
                if (match(db, word)) list.push({ text: bracket(db), displayText: db + '   database' });
            });
            // Schemas
            ac.schemas.forEach(function(s) {
                if (match(s, word)) list.push({ text: bracket(s), displayText: s + '   schema' });
            });
            // Tables
            for (var t in tables) {
                if (t.indexOf('.') === -1 && match(t, word))
                    list.push({ text: bracket(t), displayText: t + '   table' });
            }
            // Views
            ac.views.forEach(function(v) {
                if (v.indexOf('.') === -1 && match(v, word))
                    list.push({ text: bracket(v), displayText: v + '   view' });
            });
            // Procs
            ac.procs.forEach(function(p) {
                if (p.indexOf('.') === -1 && match(p, word))
                    list.push({ text: bracket(p), displayText: p + '   procedure' });
            });
            // Functions
            ac.funcs.forEach(function(f) {
                if (f.indexOf('.') === -1 && match(f, word))
                    list.push({ text: bracket(f), displayText: f + '   function' });
            });
            // Columns
            for (var t in tables) {
                if (t.indexOf('.') > -1) continue;
                (tables[t] || []).forEach(function(c) {
                    if (match(c, word)) list.push({ text: bracket(c), displayText: c + '   col (' + t + ')' });
                });
            }
            // Keywords
            KW.forEach(function(k) {
                if (match(k, word)) list.push({ text: k, displayText: k });
            });

        } else if (dotCount === 1) {
            // One dot: could be DB.schema, schema.table, or table.column
            var p0 = parts[0], p1 = parts[1];

            // DB. -> suggest schemas
            ac.databases.forEach(function(db) {
                if (db.toLowerCase() === p0) {
                    ac.schemas.forEach(function(s) {
                        if (match(s, p1)) list.push({ text: bracket(db) + '.' + bracket(s), displayText: db + '.' + s + '   schema' });
                    });
                }
            });

            // schema. -> suggest tables, views, procs, funcs
            ac.schemas.forEach(function(s) {
                if (s.toLowerCase() === p0) {
                    for (var t in tables) {
                        if (t.indexOf('.') === -1 && match(t, p1))
                            list.push({ text: bracket(s) + '.' + bracket(t), displayText: s + '.' + t + '   table' });
                    }
                    ac.views.forEach(function(v) {
                        if (v.indexOf('.') === -1 && match(v, p1))
                            list.push({ text: bracket(s) + '.' + bracket(v), displayText: s + '.' + v + '   view' });
                    });
                    ac.procs.forEach(function(pr) {
                        if (pr.indexOf('.') === -1 && match(pr, p1))
                            list.push({ text: bracket(s) + '.' + bracket(pr), displayText: s + '.' + pr + '   procedure' });
                    });
                    ac.funcs.forEach(function(f) {
                        if (f.indexOf('.') === -1 && match(f, p1))
                            list.push({ text: bracket(s) + '.' + bracket(f), displayText: s + '.' + f + '   function' });
                    });
                }
            });

            // table. -> suggest columns
            for (var t in tables) {
                if (t.indexOf('.') === -1 && t.toLowerCase() === p0) {
                    (tables[t] || []).forEach(function(c) {
                        if (match(c, p1)) list.push({ text: bracket(t) + '.' + bracket(c), displayText: t + '.' + c + '   column' });
                    });
                }
            }

        } else if (dotCount === 2) {
            // Two dots: DB.schema.table or schema.table.column
            var p0 = parts[0], p1 = parts[1], p2 = parts[2];

            // DB.schema. -> suggest tables (always try, even if db not in list)
            // First check if p0 looks like a database name
            var isDb = false;
            var dbMatch = '';
            ac.databases.forEach(function(db) { if (db.toLowerCase() === p0) { isDb = true; dbMatch = db; } });

            // Always suggest tables for DB.schema.table pattern
            for (var t in tables) {
                if (t.indexOf('.') === -1 && match(t, p2))
                    list.push({ text: bracket(dbMatch || p0) + '.' + bracket(p1) + '.' + bracket(t), displayText: (dbMatch || p0) + '.' + p1 + '.' + t + '   table' });
            }
            ac.views.forEach(function(v) {
                if (v.indexOf('.') === -1 && match(v, p2))
                    list.push({ text: bracket(dbMatch || p0) + '.' + bracket(p1) + '.' + bracket(v), displayText: (dbMatch || p0) + '.' + p1 + '.' + v + '   view' });
            });
            ac.procs.forEach(function(pr) {
                if (pr.indexOf('.') === -1 && match(pr, p2))
                    list.push({ text: bracket(dbMatch || p0) + '.' + bracket(p1) + '.' + bracket(pr), displayText: (dbMatch || p0) + '.' + p1 + '.' + pr + '   procedure' });
            });

            // schema.table. -> suggest columns
            for (var t in tables) {
                if (t.indexOf('.') === -1 && t.toLowerCase() === p1) {
                    (tables[t] || []).forEach(function(c) {
                        if (match(c, p2)) list.push({ text: bracket(p0) + '.' + bracket(t) + '.' + bracket(c), displayText: p0 + '.' + t + '.' + c + '   column' });
                    });
                }
            }

        } else if (dotCount === 3) {
            // Three dots: DB.schema.table.column
            var p0 = parts[0], p1 = parts[1], p2 = parts[2], p3 = parts[3];
            for (var t in tables) {
                if (t.indexOf('.') === -1 && t.toLowerCase() === p2) {
                    (tables[t] || []).forEach(function(c) {
                        if (match(c, p3)) list.push({ text: bracket(p0) + '.' + bracket(p1) + '.' + bracket(p2) + '.' + bracket(c), displayText: p0 + '.' + p1 + '.' + p2 + '.' + c + '   column' });
                    });
                }
            }
        }

        if (list.length === 0) return;

        // Remove duplicates
        var seen = {};
        list = list.filter(function(item) {
            if (seen[item.displayText]) return false;
            seen[item.displayText] = true;
            return true;
        });
        list = list.slice(0, 20);

        cm.showHint({
            completeSingle: false,
            hint: function() {
                return { list: list, from: CodeMirror.Pos(cur.line, start), to: CodeMirror.Pos(cur.line, end) };
            }
        });
    },

    loadAutocomplete: function(tabId) {
        var self = this;
        var cid = self.connIds[tabId] || self.connId;
        var db = self.databases[tabId];
        if (!cid) return;

        self.tableData = self.tableData || {};
        self.acData = self.acData || {};
        self.tableData[tabId] = {};
        self.acData[tabId] = { databases:[], schemas:[], views:[], procs:[], funcs:[] };

        // Load databases
        API.getDatabases(cid).then(function(d) {
            self.acData[tabId].databases = d.databases || [];
        }).catch(function(){});

        if (!db) return;

        // Load schemas
        API.getSchemas(cid, db).then(function(d) {
            self.acData[tabId].schemas = d.schemas || [];

            // For each schema, load everything
            (d.schemas || []).forEach(function(schema) {
                // Tables + columns
                API.getTables(cid, db, schema).then(function(td) {
                    (td.tables || []).forEach(function(t) {
                        var fullName = schema + '.' + t.name;
                        self.tableData[tabId][t.name] = [];
                        self.tableData[tabId][fullName] = [];
                    });
                    // Load columns for tables (max 50 total)
                    var tables = (td.tables || []).slice(0, 50);
                    tables.forEach(function(t) {
                        API.getColumns(cid, db, schema, t.name).then(function(cd) {
                            var cols = (cd.columns || []).map(function(c) { return c.name; });
                            self.tableData[tabId][t.name] = cols;
                            self.tableData[tabId][schema + '.' + t.name] = cols;
                        }).catch(function(){});
                    });
                }).catch(function(){});

                // Views
                API.getViews(cid, db, schema).then(function(vd) {
                    (vd.views || []).forEach(function(v) {
                        self.acData[tabId].views.push(v);
                        self.acData[tabId].views.push(schema + '.' + v);
                    });
                }).catch(function(){});

                // Stored Procedures
                API.getProcedures(cid, db, schema).then(function(pd) {
                    (pd.procedures || []).forEach(function(p) {
                        self.acData[tabId].procs.push(p);
                        self.acData[tabId].procs.push(schema + '.' + p);
                    });
                }).catch(function(){});

                // Functions
                API.getFunctions(cid, db, schema).then(function(fd) {
                    (fd.functions || []).forEach(function(f) {
                        self.acData[tabId].funcs.push(f);
                        self.acData[tabId].funcs.push(schema + '.' + f);
                    });
                }).catch(function(){});
            });
        }).catch(function(){});

        // Reload when database changes
        var select = document.getElementById('qdb-' + tabId);
        if (select && !select._acBound) {
            select._acBound = true;
            select.addEventListener('change', function() {
                self.databases[tabId] = select.value;
                self.loadAutocomplete(tabId);
            });
        }
    },

    toggleResults: function(tabId) {
        var results = document.getElementById('qresults-' + tabId);
        var splitter = document.getElementById('qsplit-' + tabId);
        var editor = document.getElementById('qeditor-' + tabId);
        if (!results) return;

        if (results.style.display === 'none') {
            // Show results
            results.style.display = '';
            if (splitter) splitter.style.display = '';
            if (editor) editor.style.flex = '';
        } else {
            // Hide results - editor takes full space
            results.style.display = 'none';
            if (splitter) splitter.style.display = 'none';
            if (editor) { editor.style.flex = '1'; editor.style.height = ''; }
        }
        // Refresh CodeMirror after resize
        if (this.editors[tabId]) {
            var ed = this.editors[tabId];
            setTimeout(function() { ed.refresh(); }, 50);
        }
    },

    doExport: function(tabId, format) {
        var editor = this.editors[tabId];
        var sql = editor ? editor.getValue() : '';
        if (!sql || !sql.trim()) { Toast.warning('Enter a query first'); return; }
        var db = this.databases[tabId] || '';

        var cid = this.connIds[tabId] || this.connId;
        fetch('/api/query/export', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ connection_id: cid, sql: sql, database: db, format: format })
        }).then(function(r) { return r.blob(); }).then(function(blob) {
            var url = URL.createObjectURL(blob);
            var a = document.createElement('a');
            a.href = url; a.download = 'export.' + format; a.click();
            URL.revokeObjectURL(url);
            Toast.success('Exported');
        }).catch(function(e) { Toast.error(e.message); });
    }
};
