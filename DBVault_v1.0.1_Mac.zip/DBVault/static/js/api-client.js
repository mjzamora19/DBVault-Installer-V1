/* API Client (ES5) */
var API = {
    base: '/api',

    request: function(method, path, body) {
        var opts = { method: method, headers: {} };
        if (method !== 'GET') {
            opts.headers['Content-Type'] = 'application/json';
            opts.body = JSON.stringify(body || {});
        }
        return fetch(this.base + path, opts).then(function(res) {
            return res.text().then(function(text) {
                var data;
                try { data = JSON.parse(text); }
                catch(e) { throw new Error('Server error (' + res.status + ')'); }
                if (data.error) throw new Error(data.message || 'API error');
                return data;
            });
        });
    },

    get: function(path) { return this.request('GET', path); },
    post: function(path, body) { return this.request('POST', path, body); },
    put: function(path, body) { return this.request('PUT', path, body); },
    del: function(path, body) { return this.request('DELETE', path, body); },

    listConnections: function() { return this.get('/connections'); },
    detectInstances: function() { return this.get('/connections/detect'); },
    createConnection: function(data) { return this.post('/connections', data); },
    updateConnection: function(id, data) { return this.put('/connections/' + id, data); },
    deleteConnection: function(id) { return this.del('/connections/' + id); },
    testConnection: function(id) { return this.post('/connections/' + id + '/test'); },
    testConnectionDirect: function(data) { return this.post('/connections/test-direct', data); },
    connect: function(id) { return this.post('/connections/' + id + '/connect'); },
    disconnect: function(id) { return this.post('/connections/' + id + '/disconnect'); },

    getDatabases: function(connId) { return this.get('/schema/' + connId + '/databases'); },
    getSchemas: function(connId, db) { return this.get('/schema/' + connId + '/schemas?db=' + enc(db)); },
    getTables: function(connId, db, schema) { return this.get('/schema/' + connId + '/tables?db=' + enc(db) + '&schema=' + enc(schema)); },
    getViews: function(connId, db, schema) { return this.get('/schema/' + connId + '/views?db=' + enc(db) + '&schema=' + enc(schema)); },
    getColumns: function(connId, db, schema, table) { return this.get('/schema/' + connId + '/columns?db=' + enc(db) + '&schema=' + enc(schema) + '&table=' + enc(table)); },
    getProcedures: function(connId, db, schema) { return this.get('/schema/' + connId + '/procedures?db=' + enc(db) + '&schema=' + enc(schema)); },
    getFunctions: function(connId, db, schema) { return this.get('/schema/' + connId + '/functions?db=' + enc(db) + '&schema=' + enc(schema)); },
    getTriggers: function(connId, db, schema) { return this.get('/schema/' + connId + '/triggers?db=' + enc(db) + '&schema=' + enc(schema)); },
    getDefinition: function(connId, db, schema, name, type) { return this.get('/schema/' + connId + '/definition?db=' + enc(db) + '&schema=' + enc(schema) + '&name=' + enc(name) + '&type=' + enc(type)); },

    executeQuery: function(connId, sql, database, offset, limit) {
        return this.post('/query/execute', { connection_id: connId, sql: sql, database: database, offset: offset || 0, limit: limit || 100 });
    },

    getRows: function(connId, db, schema, table, offset, limit, sort, order, filters) {
        var url = '/data/' + connId + '/rows?db=' + enc(db) + '&schema=' + enc(schema) + '&table=' + enc(table) + '&offset=' + (offset||0) + '&limit=' + (limit||100);
        if (sort) url += '&sort=' + enc(sort) + '&order=' + enc(order||'asc');
        if (filters) url += '&filter=' + enc(JSON.stringify(filters));
        return this.get(url);
    },
    insertRow: function(connId, db, schema, table, values) { return this.post('/data/' + connId + '/rows', { database: db, schema: schema, table: table, values: values }); },
    updateRow: function(connId, db, schema, table, pk, changes) { return this.put('/data/' + connId + '/rows', { database: db, schema: schema, table: table, pk: pk, changes: changes }); },
    deleteRow: function(connId, db, schema, table, pk) { return this.del('/data/' + connId + '/rows', { database: db, schema: schema, table: table, pk: pk }); },

    createTable: function(connId, db, schema, tableName, columns) { return this.post('/ddl/' + connId + '/create-table', { database: db, schema: schema, table_name: tableName, columns: columns }); },
    dropTable: function(connId, db, schema, tableName) { return this.post('/ddl/' + connId + '/drop-table', { database: db, schema: schema, table_name: tableName, confirm: true }); },
    getTableDDL: function(connId, db, schema, table) { return this.get('/ddl/' + connId + '/table-ddl?db=' + enc(db) + '&schema=' + enc(schema) + '&table=' + enc(table)); }
};

function enc(v) { return encodeURIComponent(v || ''); }
