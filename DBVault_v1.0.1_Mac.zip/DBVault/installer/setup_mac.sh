#!/bin/bash
# DBVault - Mac Setup
echo ""
echo "  =========================================="
echo "  DBVault v1.0 - Mac Setup"
echo "  Database Management Tool"
echo "  =========================================="
echo ""

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "  Python 3 not found."
    echo "  Install from: https://www.python.org/downloads/"
    echo "  Or run: brew install python"
    open "https://www.python.org/downloads/" 2>/dev/null
    exit 1
fi

echo "  [1/3] Python found: $(python3 --version)"
echo ""

echo "  [2/3] Installing dependencies..."
pip3 install flask flask-cors psycopg2-binary cryptography --quiet 2>/dev/null
echo "  Done."
echo ""

# Create launcher script
SCRIPT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
echo "  [3/3] Creating launcher..."
cat > "$HOME/Desktop/DBVault.command" << EOF
#!/bin/bash
cd "$SCRIPT_DIR"
python3 launcher.py
EOF
chmod +x "$HOME/Desktop/DBVault.command"
echo "  Desktop launcher created."
echo ""

echo "  =========================================="
echo "  Setup Complete!"
echo "  =========================================="
echo ""
echo "  Double-click 'DBVault' on your desktop to start."
echo ""

read -p "  Launch now? (y/n): " choice
if [ "$choice" = "y" ] || [ "$choice" = "Y" ]; then
    cd "$SCRIPT_DIR"
    python3 launcher.py
fi
