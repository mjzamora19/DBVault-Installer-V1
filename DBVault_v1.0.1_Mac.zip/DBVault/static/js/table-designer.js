/* Table Designer - Create/Alter tables with visual UI */

var TableDesigner = {
    connId: null,
    database: null,
    schema: null,
    columns: [],
    dbType: 'mssql',

    init(connId, database, schema) {
        this.connId = connId;
        this.database = database;
        this.schema = schema || 'dbo';
        this.columns = [
            { name: 'id', type: 'int', length: '', precision: '', scale: '', nullable: false, default: '', pk: true, identity: true },
        ];

        const conn = App.state.connections.find(c => c.id === connId);
        this.dbType = conn?.type || 'mssql';

        const main = document.getElementById('main-content');
        main.innerHTML = `
            <div class="designer-page">
                <h2>Create New Table</h2>
                <div class="form-row">
                    <div class="form-group">
                        <label>Database</label>
                        <input type="text" id="designer-db" value="${esc(database || '')}" placeholder="database">
                    </div>
                    <div class="form-group">
                        <label>Schema</label>
                        <input type="text" id="designer-schema" value="${esc(schema || 'dbo')}" placeholder="dbo">
                    </div>
                    <div class="form-group">
                        <label>Table Name</label>
                        <input type="text" id="designer-table" placeholder="my_table" oninput="TableDesigner.updatePreview()">
                    </div>
                </div>

                <h3 style="margin:20px 0 8px;font-size:13px;color:var(--text-muted)">COLUMNS</h3>
                <table class="column-editor">
                    <thead>
                        <tr>
                            <th style="width:40px">PK</th>
                            <th>Name</th>
                            <th style="width:120px">Type</th>
                            <th style="width:80px">Length</th>
                            <th style="width:50px">Null</th>
                            <th style="width:120px">Default</th>
                            <th style="width:60px">Identity</th>
                            <th style="width:40px"></th>
                        </tr>
                    </thead>
                    <tbody id="designer-columns"></tbody>
                </table>

                <div style="margin:12px 0; display:flex; gap:8px">
                    <button class="btn btn-sm" onclick="TableDesigner.addColumn()">+ Add Column</button>
                </div>

                <h3 style="margin:20px 0 8px;font-size:13px;color:var(--text-muted)">SQL PREVIEW</h3>
                <div class="sql-preview" id="designer-preview">-- Define columns above to see preview</div>

                <div style="margin:20px 0; display:flex; gap:8px">
                    <button class="btn btn-primary" onclick="TableDesigner.createTable()">Create Table</button>
                    <button class="btn" onclick="TableDesigner.copySQL()">Copy SQL</button>
                    <button class="btn" onclick="App.showDashboard()">Cancel</button>
                </div>
            </div>
        `;

        this.renderColumns();
    },

    getTypes() {
        if (this.dbType === 'mssql') {
            return ['int','bigint','smallint','tinyint','bit','decimal','numeric','float','real','money',
                    'char','varchar','nchar','nvarchar','text','ntext',
                    'date','time','datetime','datetime2','datetimeoffset',
                    'binary','varbinary','uniqueidentifier','xml'];
        } else {
            return ['integer','bigint','smallint','serial','bigserial','boolean',
                    'decimal','numeric','real','double precision','money',
                    'char','varchar','text',
                    'date','time','timestamp','timestamptz',
                    'bytea','uuid','json','jsonb','xml'];
        }
    },

    renderColumns() {
        const tbody = document.getElementById('designer-columns');
        tbody.innerHTML = '';
        const types = this.getTypes();

        this.columns.forEach((col, i) => {
            const typeOptions = types.map(t => `<option value="${t}" ${col.type === t ? 'selected' : ''}>${t}</option>`).join('');
            tbody.innerHTML += `
                <tr>
                    <td><input type="checkbox" ${col.pk ? 'checked' : ''} onchange="TableDesigner.updateCol(${i},'pk',this.checked)"></td>
                    <td><input type="text" value="${esc(col.name)}" placeholder="column_name" onchange="TableDesigner.updateCol(${i},'name',this.value)"></td>
                    <td><select onchange="TableDesigner.updateCol(${i},'type',this.value)">${typeOptions}</select></td>
                    <td><input type="text" value="${esc(col.length || '')}" placeholder="" onchange="TableDesigner.updateCol(${i},'length',this.value)"></td>
                    <td><input type="checkbox" ${col.nullable ? 'checked' : ''} onchange="TableDesigner.updateCol(${i},'nullable',this.checked)"></td>
                    <td><input type="text" value="${esc(col.default || '')}" placeholder="" onchange="TableDesigner.updateCol(${i},'default',this.value)"></td>
                    <td><input type="checkbox" ${col.identity ? 'checked' : ''} onchange="TableDesigner.updateCol(${i},'identity',this.checked)"></td>
                    <td><button class="btn btn-sm btn-danger" onclick="TableDesigner.removeColumn(${i})" style="padding:2px 6px">x</button></td>
                </tr>
            `;
        });

        this.updatePreview();
    },

    addColumn() {
        this.columns.push({ name: '', type: 'varchar', length: '255', precision: '', scale: '', nullable: true, default: '', pk: false, identity: false });
        this.renderColumns();
    },

    removeColumn(idx) {
        this.columns.splice(idx, 1);
        this.renderColumns();
    },

    updateCol(idx, field, value) {
        this.columns[idx][field] = value;
        this.updatePreview();
    },

    updatePreview() {
        const tableName = document.getElementById('designer-table')?.value || 'my_table';
        const schema = document.getElementById('designer-schema')?.value || 'dbo';
        const qi = this.dbType === 'mssql' ? (n => `[${n}]`) : (n => `"${n}"`);

        const colDefs = [];
        const pkCols = [];

        this.columns.forEach(col => {
            if (!col.name) return;
            let typeStr = col.type.toUpperCase();
            if (col.length) typeStr += `(${col.length})`;

            const parts = [qi(col.name)];

            if (col.identity) {
                if (this.dbType === 'mssql') {
                    parts.push(typeStr, 'IDENTITY(1,1)');
                } else {
                    parts.push('SERIAL');
                }
            } else {
                parts.push(typeStr);
            }

            parts.push(col.nullable ? 'NULL' : 'NOT NULL');

            if (col.default && !col.identity) {
                parts.push(`DEFAULT ${col.default}`);
            }

            colDefs.push('    ' + parts.join(' '));
            if (col.pk) pkCols.push(col.name);
        });

        if (pkCols.length) {
            colDefs.push(`    CONSTRAINT ${qi('PK_' + tableName)} PRIMARY KEY (${pkCols.map(qi).join(', ')})`);
        }

        const sql = `CREATE TABLE ${qi(schema)}.${qi(tableName)} (\n${colDefs.join(',\n')}\n);`;
        document.getElementById('designer-preview').textContent = sql;
    },

    async createTable() {
        const tableName = document.getElementById('designer-table')?.value;
        const database = document.getElementById('designer-db')?.value;
        const schema = document.getElementById('designer-schema')?.value || 'dbo';

        if (!tableName) { Toast.warning('Enter a table name'); return; }
        if (!this.columns.some(c => c.name)) { Toast.warning('Add at least one column'); return; }

        const cols = this.columns.filter(c => c.name).map(c => ({
            name: c.name,
            type: c.type,
            length: c.length ? parseInt(c.length) : undefined,
            nullable: c.nullable,
            default: c.default || undefined,
            primary_key: c.pk,
            identity: c.identity,
        }));

        try {
            await API.createTable(this.connId, database, schema, tableName, cols);
            Toast.success(`Table ${tableName} created successfully!`);
            App.loadSchemaTree(this.connId);
        } catch (e) {
            Toast.error(`Create failed: ${e.message}`);
        }
    },

    copySQL() {
        const sql = document.getElementById('designer-preview').textContent;
        navigator.clipboard.writeText(sql).then(() => Toast.success('SQL copied to clipboard'));
    },
};
