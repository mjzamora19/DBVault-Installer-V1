/* Virtual Scrolling Data Grid - Handles 10M+ rows */

var DataGrid = {
    connId: null,
    database: null,
    schema: null,
    table: null,
    columns: [],
    totalRows: 0,
    pageSize: 200,
    pageCache: new Map(),
    maxCachedPages: 50,
    rowHeight: 34,
    sortCol: null,
    sortOrder: 'asc',
    pendingChanges: new Map(),
    pkColumns: [],
    editingCell: null,

    initInPanel: function(connId, database, schema, table, panel) {
        // Simple table view in a tab panel
        var self = this;
        panel.innerHTML = '<div style="padding:8px 12px;background:var(--bg2);border-bottom:1px solid var(--border);display:flex;align-items:center;gap:8px">' +
            '<strong style="color:var(--fg)">' + esc(schema) + '.' + esc(table) + '</strong>' +
            '<span id="dg-count-' + panel.id + '" style="color:var(--fg3);font-size:11px">Loading...</span>' +
            '</div>' +
            '<div id="dg-grid-' + panel.id + '" style="flex:1;overflow:auto"></div>';

        API.getRows(connId, database, schema, table, 0, 200).then(function(result) {
            var countEl = document.getElementById('dg-count-' + panel.id);
            if (countEl) countEl.textContent = '~' + (result.total_rows||0).toLocaleString() + ' rows | ' + result.execution_time_ms + 'ms';

            var gridEl = document.getElementById('dg-grid-' + panel.id);
            if (!gridEl) return;

            var table_el = document.createElement('table');
            table_el.style.cssText = 'border-collapse:collapse;width:max-content;min-width:100%;';

            var thead = '<thead><tr><th style="padding:6px 8px;background:var(--bg2);border:1px solid var(--border);color:var(--fg2);font-size:10px;position:sticky;top:0;z-index:1">#</th>';
            (result.columns||[]).forEach(function(col) {
                thead += '<th style="padding:6px 10px;background:var(--bg2);border:1px solid var(--border);color:var(--accent-light);font-size:11px;font-weight:600;white-space:nowrap;position:sticky;top:0;z-index:1">' + esc(col.name) + '</th>';
            });
            thead += '</tr></thead>';

            var tbody = '<tbody>';
            (result.rows||[]).forEach(function(row, idx) {
                tbody += '<tr>';
                tbody += '<td style="padding:4px 8px;border:1px solid var(--border);color:var(--fg3);font-size:10px;text-align:center;background:var(--bg1)">' + (idx+1) + '</td>';
                row.forEach(function(val) {
                    if (val === null) {
                        tbody += '<td style="padding:4px 10px;border:1px solid var(--border);color:var(--fg3);font-style:italic;font-size:12px;font-family:JetBrains Mono,monospace">NULL</td>';
                    } else {
                        tbody += '<td style="padding:4px 10px;border:1px solid var(--border);color:var(--fg);font-size:12px;font-family:JetBrains Mono,monospace;white-space:nowrap">' + esc(String(val)) + '</td>';
                    }
                });
                tbody += '</tr>';
            });
            tbody += '</tbody>';

            table_el.innerHTML = thead + tbody;
            gridEl.appendChild(table_el);

            App.updateRowCount(result.total_rows);
        }).catch(function(e) {
            var gridEl = document.getElementById('dg-grid-' + panel.id);
            if (gridEl) gridEl.innerHTML = '<div class="empty-state"><p style="color:var(--red)">' + e.message + '</p></div>';
        });
    },

    async init(connId, database, schema, table) {
        this.connId = connId;
        this.database = database;
        this.schema = schema;
        this.table = table;
        this.pageCache.clear();
        this.pendingChanges.clear();
        this.sortCol = null;
        this.sortOrder = 'asc';

        const main = document.getElementById('main-content');
        main.innerHTML = `
            <div class="data-grid-wrapper">
                <div class="data-grid-toolbar">
                    <span class="table-name">${esc(schema)}.${esc(table)}</span>
                    <span class="row-count" id="grid-row-count">Loading...</span>
                    <button class="btn btn-sm btn-primary" onclick="DataGrid.addRow()">+ Add Row</button>
                    <button class="btn btn-sm btn-danger" onclick="DataGrid.deleteSelected()">Delete</button>
                    <button class="btn btn-sm" onclick="DataGrid.refresh()">Refresh</button>
                    <button class="btn btn-sm" onclick="DataGrid.exportTable()">Export</button>
                </div>
                <div class="data-grid-container" id="grid-container">
                    <div class="data-grid-header" id="grid-header"></div>
                    <div class="data-grid-body" id="grid-body">
                        <div id="grid-scroll-container"></div>
                    </div>
                </div>
                <div class="data-grid-footer" id="grid-footer">
                    <div class="page-info" id="grid-page-info">Loading...</div>
                    <div class="pending-changes" id="grid-pending" style="display:none">
                        <span id="grid-pending-count">0</span> pending changes
                        <button class="btn btn-sm btn-success" onclick="DataGrid.saveChanges()">Save</button>
                        <button class="btn btn-sm" onclick="DataGrid.discardChanges()">Discard</button>
                    </div>
                </div>
            </div>
        `;

        await this.loadMetadata();
        await this.loadPage(0);
        this.setupVirtualScroll();
    },

    async loadMetadata() {
        try {
            const data = await API.getColumns(this.connId, this.database, this.schema, this.table);
            this.columns = data.columns || [];
            this.pkColumns = this.columns.filter(c => c.is_pk).map(c => c.name);
            this.renderHeader();
        } catch (e) {
            Toast.error(`Failed to load columns: ${e.message}`);
        }
    },

    renderHeader() {
        const header = document.getElementById('grid-header');
        let html = '<div class="col-header-row-num">#</div>';
        this.columns.forEach(col => {
            const w = this.getColWidth(col);
            const sortIndicator = this.sortCol === col.name
                ? (this.sortOrder === 'asc' ? ' &#9650;' : ' &#9660;')
                : '';
            html += `<div class="col-header" style="width:${w}px" onclick="DataGrid.toggleSort('${esc(col.name)}')">`
                + `${esc(col.name)} <span class="sort-indicator">${sortIndicator}</span>`
                + `<span style="color:var(--text-muted);font-weight:400;font-size:9px;margin-left:4px">${col.type}${col.is_pk ? ' PK' : ''}</span></div>`;
        });
        header.innerHTML = html;
    },

    getColWidth(col) {
        const nameLen = col.name.length * 8 + 60;
        return Math.max(100, Math.min(300, nameLen));
    },

    async loadPage(offset) {
        const pageNum = Math.floor(offset / this.pageSize);
        if (this.pageCache.has(pageNum)) return this.pageCache.get(pageNum);

        try {
            const result = await API.getRows(
                this.connId, this.database, this.schema, this.table,
                pageNum * this.pageSize, this.pageSize,
                this.sortCol, this.sortOrder
            );
            this.totalRows = result.total_rows;
            this.updateInfo();

            const page = { rows: result.rows, offset: pageNum * this.pageSize };
            this.pageCache.set(pageNum, page);

            // LRU eviction
            if (this.pageCache.size > this.maxCachedPages) {
                const firstKey = this.pageCache.keys().next().value;
                this.pageCache.delete(firstKey);
            }

            return page;
        } catch (e) {
            Toast.error(`Failed to load data: ${e.message}`);
            return null;
        }
    },

    updateInfo() {
        const countEl = document.getElementById('grid-row-count');
        if (countEl) countEl.textContent = `~${formatNumber(this.totalRows)} rows`;
        App.updateRowCount(this.totalRows);
    },

    setupVirtualScroll() {
        const body = document.getElementById('grid-body');
        const scrollContainer = document.getElementById('grid-scroll-container');

        // Calculate scroll height with ratio mapping for large datasets
        const maxScrollHeight = 10000000; // 10M px max
        const naturalHeight = this.totalRows * this.rowHeight;
        const scrollHeight = Math.min(naturalHeight, maxScrollHeight);
        const useRatioMapping = naturalHeight > maxScrollHeight;

        scrollContainer.style.height = scrollHeight + 'px';
        scrollContainer.style.position = 'relative';

        let renderFrame = null;
        body.addEventListener('scroll', () => {
            if (renderFrame) cancelAnimationFrame(renderFrame);
            renderFrame = requestAnimationFrame(() => this.renderVisibleRows(body, scrollHeight, useRatioMapping));
        });

        this.renderVisibleRows(body, scrollHeight, useRatioMapping);
    },

    async renderVisibleRows(body, scrollHeight, useRatioMapping) {
        const scrollTop = body.scrollTop;
        const viewportHeight = body.clientHeight;
        const scrollContainer = document.getElementById('grid-scroll-container');

        let firstRow, lastRow;
        if (useRatioMapping) {
            const ratio = scrollTop / Math.max(1, scrollHeight - viewportHeight);
            firstRow = Math.floor(ratio * Math.max(0, this.totalRows - Math.floor(viewportHeight / this.rowHeight)));
            lastRow = firstRow + Math.ceil(viewportHeight / this.rowHeight) + 10;
        } else {
            firstRow = Math.floor(scrollTop / this.rowHeight);
            lastRow = firstRow + Math.ceil(viewportHeight / this.rowHeight) + 10;
        }

        firstRow = Math.max(0, firstRow - 5);
        lastRow = Math.min(this.totalRows, lastRow);

        // Determine which pages we need
        const firstPage = Math.floor(firstRow / this.pageSize);
        const lastPage = Math.floor(lastRow / this.pageSize);

        // Load needed pages
        for (let p = firstPage; p <= lastPage; p++) {
            if (!this.pageCache.has(p)) {
                await this.loadPage(p * this.pageSize);
            }
        }

        // Render rows
        let html = '';
        for (let i = firstRow; i < lastRow; i++) {
            const pageNum = Math.floor(i / this.pageSize);
            const pageData = this.pageCache.get(pageNum);
            if (!pageData) continue;

            const rowIdx = i - pageData.offset;
            if (rowIdx < 0 || rowIdx >= pageData.rows.length) continue;

            const row = pageData.rows[rowIdx];
            const topPos = useRatioMapping
                ? ((i - firstRow) * this.rowHeight)
                : (i * this.rowHeight);

            const rowKey = this.getRowKey(row);
            const isModified = this.pendingChanges.has(rowKey);

            html += `<div class="data-grid-row${isModified ? ' modified' : ''}" style="position:absolute;top:${topPos}px;width:100%;height:${this.rowHeight}px" data-row-idx="${i}">`;
            html += `<div class="row-num">${i + 1}</div>`;

            this.columns.forEach((col, ci) => {
                const w = this.getColWidth(col);
                const val = row[ci];
                const changeKey = `${rowKey}:${col.name}`;
                const isChanged = this.pendingChanges.has(rowKey) && this.pendingChanges.get(rowKey).has(col.name);

                if (val === null) {
                    html += `<div class="cell null-value${isChanged ? ' modified' : ''}" style="width:${w}px" onclick="DataGrid.startEdit(${i},${ci})">NULL</div>`;
                } else {
                    html += `<div class="cell${isChanged ? ' modified' : ''}" style="width:${w}px" onclick="DataGrid.startEdit(${i},${ci})">${esc(String(val))}</div>`;
                }
            });
            html += '</div>';
        }

        // Set container to position rows relatively to viewport scroll
        if (useRatioMapping) {
            scrollContainer.innerHTML = `<div style="position:relative;top:${scrollTop}px">${html}</div>`;
        } else {
            scrollContainer.innerHTML = html;
        }

        // Update footer
        const pageInfo = document.getElementById('grid-page-info');
        if (pageInfo) {
            pageInfo.textContent = `Rows ${firstRow + 1} - ${Math.min(lastRow, this.totalRows)} of ${formatNumber(this.totalRows)}`;
        }
    },

    getRowKey(row) {
        if (this.pkColumns.length) {
            return this.pkColumns.map(pk => {
                const idx = this.columns.findIndex(c => c.name === pk);
                return row[idx];
            }).join('|');
        }
        return row.join('|');
    },

    startEdit(rowIdx, colIdx) {
        const pageNum = Math.floor(rowIdx / this.pageSize);
        const pageData = this.pageCache.get(pageNum);
        if (!pageData) return;

        const localIdx = rowIdx - pageData.offset;
        if (localIdx < 0 || localIdx >= pageData.rows.length) return;

        const row = pageData.rows[localIdx];
        const col = this.columns[colIdx];
        const currentVal = row[colIdx];

        const cells = document.querySelectorAll(`.data-grid-row[data-row-idx="${rowIdx}"] .cell`);
        const cell = cells[colIdx];
        if (!cell) return;

        cell.className = 'cell editing';
        const input = document.createElement('input');
        input.type = 'text';
        input.value = currentVal === null ? '' : String(currentVal);
        input.style.width = cell.style.width;

        input.addEventListener('blur', () => {
            const newVal = input.value;
            if (newVal !== String(currentVal ?? '')) {
                const rowKey = this.getRowKey(row);
                if (!this.pendingChanges.has(rowKey)) {
                    this.pendingChanges.set(rowKey, new Map());
                }
                this.pendingChanges.get(rowKey).set(col.name, newVal === '' ? null : newVal);

                // Update cached row
                row[colIdx] = newVal === '' ? null : newVal;
                this.updatePendingUI();
            }
            cell.className = 'cell' + (this.pendingChanges.has(this.getRowKey(row)) ? ' modified' : '');
            cell.textContent = newVal === '' ? 'NULL' : newVal;
            if (newVal === '') cell.classList.add('null-value');
        });

        input.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') input.blur();
            if (e.key === 'Escape') { input.value = currentVal === null ? '' : String(currentVal); input.blur(); }
            if (e.key === 'Tab') {
                e.preventDefault();
                input.blur();
                const nextCol = e.shiftKey ? colIdx - 1 : colIdx + 1;
                if (nextCol >= 0 && nextCol < this.columns.length) {
                    setTimeout(() => this.startEdit(rowIdx, nextCol), 50);
                }
            }
        });

        cell.innerHTML = '';
        cell.appendChild(input);
        input.focus();
        input.select();
    },

    updatePendingUI() {
        const pending = document.getElementById('grid-pending');
        const count = document.getElementById('grid-pending-count');
        const total = Array.from(this.pendingChanges.values()).reduce((sum, m) => sum + m.size, 0);
        if (total > 0) {
            pending.style.display = 'flex';
            count.textContent = total;
        } else {
            pending.style.display = 'none';
        }
    },

    async saveChanges() {
        if (this.pendingChanges.size === 0) return;

        let saved = 0;
        let errors = 0;

        for (const [rowKey, changes] of this.pendingChanges) {
            const pk = {};
            this.pkColumns.forEach(pkCol => {
                const parts = rowKey.split('|');
                const idx = this.pkColumns.indexOf(pkCol);
                pk[pkCol] = parts[idx];
            });

            if (Object.keys(pk).length === 0) {
                Toast.warning('Cannot save: table has no primary key');
                return;
            }

            const changeObj = Object.fromEntries(changes);
            try {
                await API.updateRow(this.connId, this.database, this.schema, this.table, pk, changeObj);
                saved++;
            } catch (e) {
                errors++;
                Toast.error(`Update failed for row ${rowKey}: ${e.message}`);
            }
        }

        if (saved > 0) {
            this.pendingChanges.clear();
            this.updatePendingUI();
            Toast.success(`${saved} row(s) updated`);
            this.refresh();
        }
    },

    discardChanges() {
        this.pendingChanges.clear();
        this.updatePendingUI();
        this.refresh();
    },

    async addRow() {
        Toast.info('Click cells in the new row to enter values, then Save');
        // TODO: implement inline add row
    },

    async deleteSelected() {
        Toast.info('Right-click a row in the tree to delete, or use the query editor');
    },

    async toggleSort(colName) {
        if (this.sortCol === colName) {
            this.sortOrder = this.sortOrder === 'asc' ? 'desc' : 'asc';
        } else {
            this.sortCol = colName;
            this.sortOrder = 'asc';
        }
        this.pageCache.clear();
        this.renderHeader();

        const body = document.getElementById('grid-body');
        body.scrollTop = 0;
        await this.loadPage(0);
        const scrollContainer = document.getElementById('grid-scroll-container');
        const naturalHeight = this.totalRows * this.rowHeight;
        const scrollHeight = Math.min(naturalHeight, 10000000);
        scrollContainer.style.height = scrollHeight + 'px';
        this.renderVisibleRows(body, scrollHeight, naturalHeight > 10000000);
    },

    async refresh() {
        this.pageCache.clear();
        const body = document.getElementById('grid-body');
        await this.loadPage(0);
        const naturalHeight = this.totalRows * this.rowHeight;
        const scrollHeight = Math.min(naturalHeight, 10000000);
        const scrollContainer = document.getElementById('grid-scroll-container');
        scrollContainer.style.height = scrollHeight + 'px';
        this.renderVisibleRows(body, scrollHeight, naturalHeight > 10000000);
    },

    exportTable() {
        const sql = `SELECT * FROM [${this.schema}].[${this.table}]`;
        QueryEditor.connId = this.connId;
        QueryEditor.database = this.database;
        QueryEditor._export('csv');
    },
};
