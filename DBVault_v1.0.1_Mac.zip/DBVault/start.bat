@echo off
title DBVault
python launcher.pyc
if %errorlevel% neq 0 (
  echo.
  echo Python not found. Run installer\setup_windows.bat first.
  pause
)
