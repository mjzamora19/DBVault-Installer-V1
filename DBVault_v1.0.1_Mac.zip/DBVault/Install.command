#!/bin/bash
cd "$(dirname "$0")"
if ! command -v python3 &>/dev/null; then echo "Install Python from python.org"; open "https://python.org/downloads"; exit 1; fi
pip3 install flask flask-cors psycopg2-binary cryptography --quiet
ln -sf "$(pwd)/DBVault.command" ~/Desktop/DBVault
echo "Done! DBVault on desktop."
read -p "Launch? (y/n): " c
if [ "$c"="y" ]; then python3 launcher.pyc; fi
