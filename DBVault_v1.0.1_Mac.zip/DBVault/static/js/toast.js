/* Toast notification system (ES5) */
var Toast = {
    container: null,

    init: function() {
        this.container = document.createElement('div');
        this.container.id = 'toast-container';
        this.container.style.cssText = 'position:fixed;top:50px;right:16px;z-index:1000;display:flex;flex-direction:column;gap:8px;max-width:400px;';
        document.body.appendChild(this.container);
        var s = document.createElement('style');
        s.textContent = '@keyframes slideIn{from{transform:translateX(100%);opacity:0}to{transform:translateX(0);opacity:1}}';
        document.head.appendChild(s);
    },

    show: function(message, type, duration) {
        if (!this.container) this.init();
        type = type || 'info';
        duration = duration !== undefined ? duration : 5000;

        var toast = document.createElement('div');
        var colors = {
            success: { bg:'rgba(78,196,106,0.15)', border:'#4ec46a', icon:'OK' },
            error:   { bg:'rgba(241,76,76,0.15)', border:'#f14c4c', icon:'!!' },
            warning: { bg:'rgba(232,168,72,0.15)', border:'#e8a848', icon:'!!' },
            info:    { bg:'rgba(79,193,255,0.15)', border:'#4fc1ff', icon:'i' }
        };
        var c = colors[type] || colors.info;

        toast.style.cssText = 'background:' + c.bg + ';border:1px solid ' + c.border + ';border-radius:6px;padding:10px 14px;color:var(--fg,#ccc);font-size:12px;font-family:Segoe UI,sans-serif;display:flex;align-items:flex-start;gap:8px;box-shadow:0 4px 16px rgba(0,0,0,0.3);animation:slideIn .2s ease;';
        toast.innerHTML = '<span style="font-weight:700;color:' + c.border + '">[' + c.icon + ']</span><span style="flex:1">' + message + '</span><button onclick="this.parentElement.remove()" style="background:none;border:none;color:var(--fg3,#666);cursor:pointer;font-size:14px;padding:0 0 0 8px;">x</button>';

        this.container.appendChild(toast);

        if (type !== 'error' && duration > 0) {
            setTimeout(function() { if (toast.parentElement) toast.remove(); }, duration);
        }
    },

    success: function(msg) { this.show(msg, 'success'); },
    error: function(msg) { this.show(msg, 'error', 0); },
    warning: function(msg) { this.show(msg, 'warning'); },
    info: function(msg) { this.show(msg, 'info'); }
};
