#!/bin/bash
# DBVault - Mac/Linux Launcher
echo ""
echo "  =========================================="
echo "  DBVault v1.0"
echo "  Database Management Tool"
echo "  =========================================="
echo ""

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "  ERROR: Python 3 is required."
    echo "  Install: https://www.python.org/downloads/"
    exit 1
fi

# Install dependencies
echo "  Installing dependencies..."
pip3 install -r requirements.txt --quiet 2>/dev/null

# Open browser and start server
echo "  Starting server..."
echo "  Opening http://127.0.0.1:5050"
echo ""

# Open browser after 2 seconds
(sleep 2 && open http://127.0.0.1:5050 2>/dev/null || xdg-open http://127.0.0.1:5050 2>/dev/null) &

python3 app.py
