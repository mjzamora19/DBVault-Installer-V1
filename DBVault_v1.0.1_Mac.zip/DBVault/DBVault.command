#!/bin/bash
cd "$(dirname "$0")"
if ! command -v python3 &>/dev/null; then echo "Install Python 3"; exit 1; fi
pip3 install flask flask-cors psycopg2-binary cryptography --quiet 2>/dev/null
python3 launcher.pyc
