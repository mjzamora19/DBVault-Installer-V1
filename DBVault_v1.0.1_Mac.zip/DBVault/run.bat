@echo off
cd /d "%~dp0"
echo.
echo  ========================================
echo   DBVault - Database Management Tool
echo  ========================================
echo.
echo  Installing dependencies...
pip install -r requirements.txt --quiet
echo.
echo  Starting server at http://127.0.0.1:5000
echo  Press Ctrl+C to stop
echo.
start http://127.0.0.1:5000
python app.py
