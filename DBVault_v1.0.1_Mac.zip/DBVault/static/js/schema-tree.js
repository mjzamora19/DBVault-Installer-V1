/* Schema Tree - SSMS-style Object Explorer with Tabler Icons */

var ICONS = {
    db:     '<i class="ti ti-database" style="color:var(--accent-light)"></i>',
    schema: '<i class="ti ti-folder" style="color:var(--cyan)"></i>',
    folder: '<i class="ti ti-folder-filled" style="color:var(--orange)"></i>',
    table:  '<i class="ti ti-table" style="color:var(--accent-light)"></i>',
    view:   '<i class="ti ti-eye" style="color:var(--purple)"></i>',
    proc:   '<i class="ti ti-code" style="color:var(--green)"></i>',
    func:   '<i class="ti ti-math-function" style="color:var(--yellow)"></i>',
    trig:   '<i class="ti ti-bolt" style="color:var(--red)"></i>',
    column: '<i class="ti ti-column-insert-right" style="color:var(--fg3)"></i>',
    pk:     '<i class="ti ti-key" style="color:var(--orange)"></i>',
    arrow:  '<i class="ti ti-chevron-right"></i>'
};

var SchemaTree = {
    node: function(iconKey, label, badge, onExpand, onDbl, onCtx) {
        var n = document.createElement('div');
        n.className = 'tree-node';
        var ch = document.createElement('div');
        ch.className = 'tree-children';
        ch.style.display = 'none';

        var hdr = document.createElement('div');
        hdr.className = 'tree-node-header';

        var badgeHtml = (badge !== null && badge !== undefined) ? '<span class="badge">' + badge + '</span>' : '';
        hdr.innerHTML = '<span class="toggle">' + ICONS.arrow + '</span>' +
            '<span class="icon">' + (ICONS[iconKey] || '') + '</span>' +
            '<span class="label">' + esc(label) + '</span>' + badgeHtml;

        n.appendChild(hdr);
        n.appendChild(ch);

        var arrowEl = hdr.querySelector('.toggle');
        var loaded = false;

        if (onExpand) {
            hdr.addEventListener('click', function(e) {
                e.stopPropagation();
                if (ch.style.display === 'none') {
                    ch.style.display = '';
                    arrowEl.classList.add('expanded');
                    if (!loaded) {
                        loaded = true;
                        ch.innerHTML = '<div class="tree-loading">Loading...</div>';
                        onExpand(ch, n).catch(function(err) {
                            ch.innerHTML = '<div class="tree-loading" style="color:var(--red)">' + err.message + '</div>';
                            loaded = false;
                        });
                    }
                } else {
                    ch.style.display = 'none';
                    arrowEl.classList.remove('expanded');
                }
            });
        } else {
            arrowEl.classList.add('empty');
        }

        if (onDbl) hdr.addEventListener('dblclick', function(e) { e.stopPropagation(); onDbl(); });
        if (onCtx) hdr.addEventListener('contextmenu', function(e) { e.preventDefault(); onCtx(e); });
        return n;
    },

    createDatabaseNode: function(connId, db) {
        var self = this;
        return self.node('db', db, null, function(ch) {
            return API.getSchemas(connId, db).then(function(d) {
                ch.innerHTML = '';
                (d.schemas || []).forEach(function(s) { ch.appendChild(self.schemaNode(connId, db, s)); });
                if (!d.schemas || !d.schemas.length) ch.innerHTML = '<div class="tree-loading">No schemas</div>';
            });
        }, null, function(e) {
            showContextMenu(e, [
                { icon:'ti-file-text', label:'New Query', action: function() { App.state.activeDatabase = db; App.showQueryEditor(); }},
                { icon:'ti-refresh', label:'Refresh', action: function() { App.loadSchemaTree(connId); }},
            ]);
        });
    },

    schemaNode: function(connId, db, schema) {
        var self = this;
        return self.node('schema', schema, null, function(ch) {
            ch.innerHTML = '';
            ch.appendChild(self.folderNode('Tables', 'table', function(fch, fn) {
                return API.getTables(connId, db, schema).then(function(d) {
                    fch.innerHTML = '';
                    fn.querySelector('.badge').textContent = (d.tables||[]).length;
                    (d.tables||[]).forEach(function(t) { fch.appendChild(self.tableNode(connId, db, schema, t.name, t.row_count_approx)); });
                    if (!(d.tables||[]).length) fch.innerHTML = '<div class="tree-loading">Empty</div>';
                });
            }));
            ch.appendChild(self.folderNode('Views', 'view', function(fch, fn) {
                return API.getViews(connId, db, schema).then(function(d) {
                    fch.innerHTML = '';
                    fn.querySelector('.badge').textContent = (d.views||[]).length;
                    (d.views||[]).forEach(function(v) { fch.appendChild(self.node('view', v, null, null, function() { App.showTableBrowser(db, schema, v); })); });
                    if (!(d.views||[]).length) fch.innerHTML = '<div class="tree-loading">Empty</div>';
                });
            }));
            ch.appendChild(self.folderNode('Stored Procedures', 'proc', function(fch, fn) {
                return API.getProcedures(connId, db, schema).then(function(d) {
                    fch.innerHTML = '';
                    fn.querySelector('.badge').textContent = (d.procedures||[]).length;
                    (d.procedures||[]).forEach(function(p) { fch.appendChild(self.procNode(connId, db, schema, p)); });
                    if (!(d.procedures||[]).length) fch.innerHTML = '<div class="tree-loading">Empty</div>';
                });
            }));
            ch.appendChild(self.folderNode('Functions', 'func', function(fch, fn) {
                return API.getFunctions(connId, db, schema).then(function(d) {
                    fch.innerHTML = '';
                    fn.querySelector('.badge').textContent = (d.functions||[]).length;
                    (d.functions||[]).forEach(function(f) { fch.appendChild(self.funcNode(connId, db, schema, f)); });
                    if (!(d.functions||[]).length) fch.innerHTML = '<div class="tree-loading">Empty</div>';
                });
            }));
            ch.appendChild(self.folderNode('Triggers', 'trig', function(fch, fn) {
                return API.getTriggers(connId, db, schema).then(function(d) {
                    fch.innerHTML = '';
                    fn.querySelector('.badge').textContent = (d.triggers||[]).length;
                    (d.triggers||[]).forEach(function(t) { fch.appendChild(self.trigNode(connId, db, schema, t)); });
                    if (!(d.triggers||[]).length) fch.innerHTML = '<div class="tree-loading">Empty</div>';
                });
            }));
            return Promise.resolve();
        });
    },

    folderNode: function(label, iconKey, onExpand) {
        return this.node('folder', label, '', onExpand);
    },

    tableNode: function(connId, db, schema, table, rows) {
        var self = this;
        return self.node('table', table, rows ? formatNumber(rows) : '', function(ch) {
            return API.getColumns(connId, db, schema, table).then(function(d) {
                ch.innerHTML = '';
                (d.columns||[]).forEach(function(col) {
                    var t = col.type + (col.max_length ? '(' + col.max_length + ')' : '');
                    ch.appendChild(self.node(col.is_pk ? 'pk' : 'column', col.name, t, null));
                });
            });
        }, function() { App.showTableBrowser(db, schema, table); }, function(e) {
            var cols = [];
            API.getColumns(App.state.activeConnectionId, db, schema, table).then(function(d) {
                cols = (d.columns||[]).map(function(c) { return c.name; });
            }).catch(function(){});

            showContextMenu(e, [
                { icon:'ti-list', label:'Select Top 1000 Rows', action: function() {
                    SchemaTree.openQueryAndRun(db, 'SELECT TOP 1000 * FROM [' + schema + '].[' + table + ']');
                }},
                { icon:'ti-table', label:'View Data', action: function() {
                    App.showTableBrowser(db, schema, table);
                }},
                { icon:'ti-edit', label:'Design Table', action: function() {
                    App.showTableDesigner(db, schema);
                }},
                { divider:true },
                { icon:'ti-code', label:'Script Table as CREATE', action: function() {
                    API.getTableDDL(App.state.activeConnectionId, db, schema, table).then(function(d) {
                        SchemaTree.openQuery(db, d.sql);
                    }).catch(function(err) { Toast.error(err.message); });
                }},
                { icon:'ti-code', label:'Script Table as SELECT', action: function() {
                    API.getColumns(App.state.activeConnectionId, db, schema, table).then(function(d) {
                        var c = (d.columns||[]).map(function(col) { return '[' + col.name + ']'; });
                        var sql = 'SELECT\n    ' + c.join(',\n    ') + '\nFROM [' + schema + '].[' + table + ']\nWHERE 1 = 1';
                        SchemaTree.openQuery(db, sql);
                    }).catch(function(err) { Toast.error(err.message); });
                }},
                { icon:'ti-code', label:'Script Table as INSERT', action: function() {
                    API.getColumns(App.state.activeConnectionId, db, schema, table).then(function(d) {
                        var c = (d.columns||[]).filter(function(col) { return !col.is_pk; }).map(function(col) { return col.name; });
                        var vals = c.map(function(name) { return "'<" + name + ">'"; });
                        var sql = 'INSERT INTO [' + schema + '].[' + table + '] (\n    [' + c.join('],\n    [') + ']\n)\nVALUES (\n    ' + vals.join(',\n    ') + '\n)';
                        SchemaTree.openQuery(db, sql);
                    }).catch(function(err) { Toast.error(err.message); });
                }},
                { icon:'ti-code', label:'Script Table as UPDATE', action: function() {
                    API.getColumns(App.state.activeConnectionId, db, schema, table).then(function(d) {
                        var cols = d.columns || [];
                        var pkCols = cols.filter(function(c) { return c.is_pk; });
                        var dataCols = cols.filter(function(c) { return !c.is_pk; });
                        var setClauses = dataCols.map(function(c) { return '    [' + c.name + '] = ' + "'<" + c.name + ">'"; });
                        var whereClauses = pkCols.length > 0
                            ? pkCols.map(function(c) { return '[' + c.name + '] = <value>'; })
                            : ['<condition>'];
                        var sql = 'UPDATE [' + schema + '].[' + table + ']\nSET\n' + setClauses.join(',\n') + '\nWHERE ' + whereClauses.join(' AND ');
                        SchemaTree.openQuery(db, sql);
                    }).catch(function(err) { Toast.error(err.message); });
                }},
                { divider:true },
                { icon:'ti-code', label:'Script Table as DELETE (blocked)', disabled:true },
                { icon:'ti-trash', label:'Drop Table (blocked)', disabled:true },
            ]);
        });
    },

    procNode: function(connId, db, schema, name) {
        return this.node('proc', name, null, null, function() { SchemaTree.modifyObject(db, schema, name, 'procedure'); }, function(e) {
            showContextMenu(e, [
                { icon:'ti-edit', label:'Modify', action: function() { SchemaTree.modifyObject(db, schema, name, 'procedure'); }},
                { icon:'ti-player-play', label:'Execute', action: function() { SchemaTree.openQuery(db, 'EXEC [' + schema + '].[' + name + ']'); }},
                { icon:'ti-code', label:'Script as CREATE', action: function() { SchemaTree.scriptObject(db, schema, name, 'procedure'); }},
            ]);
        });
    },

    funcNode: function(connId, db, schema, name) {
        return this.node('func', name, null, null, function() { SchemaTree.modifyObject(db, schema, name, 'function'); }, function(e) {
            showContextMenu(e, [
                { icon:'ti-edit', label:'Modify', action: function() { SchemaTree.modifyObject(db, schema, name, 'function'); }},
                { icon:'ti-code', label:'Script as CREATE', action: function() { SchemaTree.scriptObject(db, schema, name, 'function'); }},
            ]);
        });
    },

    trigNode: function(connId, db, schema, name) {
        return this.node('trig', name, null, null, function() { SchemaTree.modifyObject(db, schema, name, 'trigger'); }, function(e) {
            showContextMenu(e, [
                { icon:'ti-edit', label:'Modify', action: function() { SchemaTree.modifyObject(db, schema, name, 'trigger'); }},
                { icon:'ti-code', label:'Script as CREATE', action: function() { SchemaTree.scriptObject(db, schema, name, 'trigger'); }},
            ]);
        });
    },

    openQuery: function(db, sql) {
        if (!App.state.activeConnectionId) { Toast.warning('Connect first'); return; }
        App.state.activeDatabase = db;
        QueryEditor.openTab(App.state.activeConnectionId, db, sql);
    },

    openQueryAndRun: function(db, sql) {
        if (!App.state.activeConnectionId) { Toast.warning('Connect first'); return; }
        App.state.activeDatabase = db;
        var tabId = QueryEditor.openTab(App.state.activeConnectionId, db, sql);
        // Auto-execute after editor loads
        setTimeout(function() { QueryEditor.execute(tabId); }, 800);
    },

    modifyObject: function(db, schema, name, type) {
        API.getDefinition(App.state.activeConnectionId, db, schema, name, type).then(function(d) {
            SchemaTree.openQuery(db, d.definition || '-- Could not load definition for [' + schema + '].[' + name + ']');
        }).catch(function(err) { Toast.error(err.message); });
    },

    scriptObject: function(db, schema, name, type) {
        API.getDefinition(App.state.activeConnectionId, db, schema, name, type).then(function(d) {
            SchemaTree.openQuery(db, d.definition || '-- Could not load definition for [' + schema + '].[' + name + ']');
        }).catch(function(err) { Toast.error(err.message); });
    }
};

function showContextMenu(e, items) {
    // Remove old menu
    var old = document.getElementById('context-menu');
    if (old) old.remove();

    var menu = document.createElement('div');
    menu.id = 'context-menu';
    menu.className = 'context-menu active';
    document.body.appendChild(menu);

    items.forEach(function(it) {
        if (it.divider) {
            var d = document.createElement('div');
            d.className = 'context-menu-divider';
            menu.appendChild(d);
        } else {
            var el = document.createElement('div');
            el.className = 'context-menu-item';
            if (it.danger) el.style.color = 'var(--red)';
            if (it.disabled) {
                el.style.color = 'var(--fg3)';
                el.style.opacity = '0.4';
                el.style.cursor = 'not-allowed';
            }
            el.innerHTML = '<i class="ti ' + (it.icon||'') + '"></i> ' + it.label;

            if (!it.disabled && it.action) {
                el.addEventListener('mousedown', function(ev) {
                    ev.preventDefault();
                    ev.stopPropagation();
                    menu.remove();
                    it.action();
                });
            }

            menu.appendChild(el);
        }
    });

    menu.style.left = Math.min(e.clientX, window.innerWidth - 220) + 'px';
    menu.style.top = Math.min(e.clientY, window.innerHeight - items.length * 32 - 20) + 'px';

    // Close menu on click anywhere else
    setTimeout(function() {
        document.addEventListener('mousedown', function closer(ev) {
            if (!menu.contains(ev.target)) {
                menu.remove();
                document.removeEventListener('mousedown', closer);
            }
        });
    }, 10);
}
