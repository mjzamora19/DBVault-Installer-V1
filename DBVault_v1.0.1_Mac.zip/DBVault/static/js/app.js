/* DBVault - Main Application (ES5) */

var App = {
    state: { connections:[], activeConnectionId:null, activeDatabase:null, activeSchema:null },

    init: function() {
        var self = this;
        Toast.init();
        self.initTheme();
        self.initModal();
        // Check role + show trial info
        fetch('/api/auth/check').then(function(r){return r.json()}).then(function(d) {
            if (d.role === 'admin') {
                var btn = document.getElementById('admin-btn');
                if (btn) btn.style.display = '';
            }
            // Show trial expiration for normal users
            if (d.role !== 'admin' && d.expires_at) {
                var exp = new Date(d.expires_at);
                var now = new Date();
                var diff = exp.getTime() - now.getTime();
                var days = Math.floor(diff / (1000 * 60 * 60 * 24));
                var hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                var banner = document.getElementById('trial-banner');
                if (banner) {
                    if (days > 0) {
                        banner.innerHTML = '<i class="ti ti-clock"></i> Trial: ' + days + ' day(s) ' + hours + ' hour(s) remaining';
                        banner.style.display = 'flex';
                        banner.style.background = days <= 1 ? '#5c2626' : '#2d2d30';
                        banner.style.color = days <= 1 ? '#f14c4c' : '#e8a848';
                    } else if (diff > 0) {
                        banner.innerHTML = '<i class="ti ti-clock"></i> Trial: ' + hours + ' hour(s) remaining';
                        banner.style.display = 'flex';
                        banner.style.background = '#5c2626';
                        banner.style.color = '#f14c4c';
                    } else {
                        banner.innerHTML = '<i class="ti ti-clock-off"></i> Trial expired. Contact admin to extend.';
                        banner.style.display = 'flex';
                        banner.style.background = '#5c2626';
                        banner.style.color = '#f14c4c';
                    }
                }
            }
        }).catch(function(){});

        self.loadConnections().then(function() {
            document.getElementById('conn-selector').onchange = function(e) {
                if (e.target.value) self.activateConnection(e.target.value);
            };
            self.showDashboard();

            // Auto-reconnect last used connection
            var lastConn = localStorage.getItem('dbvault-last-conn');
            if (lastConn) {
                var exists = false;
                for (var i = 0; i < self.state.connections.length; i++) {
                    if (self.state.connections[i].id === lastConn) { exists = true; break; }
                }
                if (exists) {
                    document.getElementById('conn-selector').value = lastConn;
                    self.activateConnection(lastConn);
                }
            }
        });
    },

    initTheme: function() {
        var saved = localStorage.getItem('dbvault-theme') || 'dark';
        document.documentElement.setAttribute('data-theme', saved);
        this.updateThemeIcon(saved);
        document.getElementById('theme-toggle').addEventListener('click', function() {
            var cur = document.documentElement.getAttribute('data-theme');
            var next = cur === 'dark' ? 'light' : 'dark';
            document.documentElement.setAttribute('data-theme', next);
            localStorage.setItem('dbvault-theme', next);
            App.updateThemeIcon(next);
        });
    },

    updateThemeIcon: function(t) {
        var b = document.getElementById('theme-toggle');
        if (b) b.innerHTML = t === 'dark' ? '<i class="ti ti-sun"></i>' : '<i class="ti ti-moon"></i>';
    },

    initModal: function() {
        document.getElementById('modal-overlay').addEventListener('click', function(e) {
            if (e.target.id === 'modal-overlay') App.closeModal();
        });
    },

    loadConnections: function() {
        var self = this;
        return API.listConnections().then(function(d) {
            self.state.connections = d.connections || [];
            var sel = document.getElementById('conn-selector');
            var cur = self.state.activeConnectionId;
            sel.innerHTML = '<option value="">No connection</option>';
            self.state.connections.forEach(function(c) {
                var o = document.createElement('option');
                o.value = c.id;
                o.textContent = c.name + ' (' + c.type.toUpperCase() + ')';
                if (c.id === cur) o.selected = true;
                sel.appendChild(o);
            });
        }).catch(function(e) { console.error(e); });
    },

    activateConnection: function(connId) {
        var self = this;
        Toast.info('Connecting...');
        var tree = document.getElementById('sidebar-tree');
        if (tree) tree.innerHTML = '<div class="tree-loading"><i class="ti ti-loader-2" style="animation:spin 1s linear infinite"></i> Connecting to server...</div>';

        return API.connect(connId).then(function() {
            self.state.activeConnectionId = connId;
            localStorage.setItem('dbvault-last-conn', connId);
            Toast.success('Connected');
            self.setStatus(true);
            return self.loadSchemaTree(connId);
        }).catch(function(e) {
            Toast.error(e.message);
            self.setStatus(false);
            if (tree) tree.innerHTML = '<div class="tree-loading" style="color:var(--red)">Connection failed</div>';
        });
    },

    setStatus: function(on) {
        document.getElementById('status-dot').className = 'status-dot' + (on ? ' connected' : '');
        var c = null;
        for (var i = 0; i < this.state.connections.length; i++) {
            if (this.state.connections[i].id === this.state.activeConnectionId) { c = this.state.connections[i]; break; }
        }
        document.getElementById('status-text').textContent = on ? (c ? c.host : '') : 'Disconnected';
    },

    loadSchemaTree: function(id) {
        var el = document.getElementById('sidebar-tree');
        el.innerHTML = '<div class="tree-loading"><i class="ti ti-loader-2" style="animation:spin 1s linear infinite"></i> Loading...</div>';
        document.getElementById('sidebar').classList.remove('collapsed');
        return API.getDatabases(id).then(function(d) {
            el.innerHTML = '';
            (d.databases || []).forEach(function(db) { el.appendChild(SchemaTree.createDatabaseNode(id, db)); });
        }).catch(function(e) { el.innerHTML = '<div class="tree-loading" style="color:var(--red)">' + e.message + '</div>'; });
    },

    /* ── Dashboard ── */
    showDashboard: function() {
        // Reset tabs
        TabManager.tabs = [];
        TabManager.activeTabId = null;

        var m = document.getElementById('main-content');
        var has = this.state.connections.length > 0;
        if (!has) {
            m.innerHTML = '<div class="dashboard-center"><div class="welcome-card">' +
                '<div class="welcome-icon"><i class="ti ti-database" style="font-size:28px"></i></div>' +
                '<h1>DBVault</h1>' +
                '<p>Click <b><i class="ti ti-plug-connected"></i> New Connection</b> in the toolbar to get started.</p>' +
                '</div></div>';
        } else {
            m.innerHTML = '<div class="dashboard"><h1>DBVault</h1><p class="subtitle">Your Connections</p>' +
                '<div class="conn-list"><div id="conn-list"></div></div></div>';
            this.renderList();
        }
    },

    renderList: function() {
        var self = this;
        var el = document.getElementById('conn-list');
        if (!el) return;
        el.innerHTML = '';
        this.state.connections.forEach(function(c) {
            var d = document.createElement('div');
            d.className = 'conn-card';
            var iconMap = {mssql:'SQL',postgresql:'PG',mysql:'My',mariadb:'Ma',oracle:'ORA',sqlite:'Lite'};
            var icon = iconMap[c.type] || 'DB';
            d.innerHTML = '<div class="conn-icon ' + c.type + '">' + icon + '</div>' +
                '<div class="conn-info"><h4>' + esc(c.name) + '</h4><p>' + esc(c.host) + ':' + (c.port||'') + ' &bull; ' + esc(c.username||'Windows Auth') + '</p></div>' +
                '<div class="conn-status"><span class="dot ' + (c.is_connected?'on':'') + '"></span>' + (c.is_connected?'Connected':'Idle') + '</div>' +
                '<div class="conn-actions">' +
                '<button class="btn btn-sm btn-primary" onclick="event.stopPropagation();App.connectAndUse(\'' + c.id + '\')"><i class="ti ti-plug-connected"></i> Connect</button>' +
                '<button class="btn btn-sm" onclick="event.stopPropagation();App.showConnectionModal(\'' + c.id + '\')"><i class="ti ti-edit"></i> Edit</button>' +
                '<button class="btn btn-sm btn-danger" onclick="event.stopPropagation();App.deleteConn(\'' + c.id + '\')"><i class="ti ti-trash"></i> Delete</button>' +
                '</div>';
            d.onclick = function() { self.connectAndUse(c.id); };
            el.appendChild(d);
        });
    },

    connectAndUse: function(id) {
        document.getElementById('conn-selector').value = id;
        return this.activateConnection(id);
    },

    deleteConn: function(id) {
        var self = this;
        if (!confirm('Delete this connection?')) return;
        API.deleteConnection(id).then(function() {
            // Clear everything related to this connection
            if (self.state.activeConnectionId === id) {
                self.state.activeConnectionId = null;
                self.state.activeDatabase = null;
                self.setStatus(false);
                // Clear sidebar
                var tree = document.getElementById('sidebar-tree');
                if (tree) tree.innerHTML = '<div class="empty-state" style="padding:20px"><p>No connection</p></div>';
            }
            // Clear auto-reconnect if this was the last connection
            if (localStorage.getItem('dbvault-last-conn') === id) {
                localStorage.removeItem('dbvault-last-conn');
            }
            // Clear connection selector
            document.getElementById('conn-selector').value = '';
            return self.loadConnections();
        }).then(function() {
            self.showDashboard();
            Toast.success('Deleted');
        }).catch(function(e) { Toast.error(e.message); });
    },

    /* ── Connection Modal ── */
    showConnectionModal: function(editId) {
        var conn = null;
        if (editId) {
            for (var i = 0; i < this.state.connections.length; i++) {
                if (this.state.connections[i].id === editId) { conn = this.state.connections[i]; break; }
            }
        }
        var opts = (conn && conn.options) ? conn.options : {};
        var dbType = conn ? conn.type : 'mssql';
        var modal = document.getElementById('modal');

        modal.innerHTML = '<div class="modal-header">' +
            '<h2>' + (conn ? 'Edit Connection' : 'New Connection') + '</h2>' +
            '<button type="button" class="modal-close" onclick="App.closeModal()">&times;</button>' +
            '</div>' +
            '<div class="modal-body" onkeydown="event.stopPropagation()">' +
                '<div class="form-group"><label>Server Type</label>' +
                '<select id="conn-type" onchange="App.onTypeChange()">' +
                    '<option value="mssql"' + (dbType==='mssql'?' selected':'') + '>Microsoft SQL Server</option>' +
                    '<option value="postgresql"' + (dbType==='postgresql'?' selected':'') + '>PostgreSQL</option>' +
                    '<option value="mysql"' + (dbType==='mysql'?' selected':'') + '>MySQL</option>' +
                    '<option value="mariadb"' + (dbType==='mariadb'?' selected':'') + '>MariaDB</option>' +
                    '<option value="oracle"' + (dbType==='oracle'?' selected':'') + '>Oracle</option>' +
                    '<option value="sqlite"' + (dbType==='sqlite'?' selected':'') + '>SQLite</option>' +
                '</select></div>' +
                '<div class="form-group"><label>Connection Name</label>' +
                '<input type="text" id="conn-name" value="' + esc(conn ? conn.name : '') + '" placeholder="My Server"></div>' +
                '<div class="form-row" id="server-section">' +
                    '<div class="form-group" style="flex:2"><label>Server <button type="button" class="btn btn-sm" style="float:right;padding:1px 6px;font-size:10px" onclick="App.detectServers()"><i class="ti ti-radar-2"></i> Detect</button></label><input type="text" id="conn-host" value="' + esc(conn ? conn.host : '') + '" placeholder="e.g. localhost\\SQLEXPRESS" list="server-list"><datalist id="server-list"></datalist></div>' +
                    '<div class="form-group"><label>Port</label><input type="text" id="conn-port" value="' + (conn ? (conn.port||'') : '') + '" placeholder="Optional"></div>' +
                '</div>' +
                '<div id="auth-section"><div class="form-group"><label>Authentication</label>' +
                '<select id="conn-auth" onchange="App.toggleAuth()">' +
                    '<option value="sql_login"' + (opts.auth_type!=='windows'&&opts.auth_type!=='entra_mfa'?' selected':'') + '>SQL Server Authentication</option>' +
                    '<option value="windows"' + (opts.auth_type==='windows'?' selected':'') + '>Windows Authentication</option>' +
                    '<option value="entra_mfa"' + (opts.auth_type==='entra_mfa'?' selected':'') + '>Microsoft Entra ID (MFA)</option>' +
                '</select></div></div>' +
                '<div id="creds-section" class="form-row">' +
                    '<div class="form-group"><label>Username</label><input type="text" id="conn-user" value="' + esc(conn ? conn.username : '') + '" placeholder="sa"></div>' +
                    '<div class="form-group"><label>Password</label><input type="password" id="conn-pass" value="" placeholder="' + (conn ? '(unchanged)' : 'password') + '"></div>' +
                '</div>' +
                '<div class="form-group"><label>Database</label><input type="text" id="conn-db" value="' + esc(conn ? conn.database : '') + '" placeholder="Default"></div>' +
                '<div class="form-group" id="encrypt-section"><label>Encryption</label>' +
                '<select id="conn-encrypt">' +
                    '<option value="mandatory"' + (opts.encrypt!=='optional'&&opts.encrypt!=='strict'?' selected':'') + '>Mandatory</option>' +
                    '<option value="optional"' + (opts.encrypt==='optional'?' selected':'') + '>Optional</option>' +
                    '<option value="strict"' + (opts.encrypt==='strict'?' selected':'') + '>Strict</option>' +
                '</select></div>' +
                '<div class="checkbox-group" id="trust-section">' +
                '<input type="checkbox" id="conn-trust"' + (opts.trust_server_certificate!==false?' checked':'') + '>' +
                '<label for="conn-trust">Trust Server Certificate</label></div>' +
                '<div class="test-result" id="test-result"><span class="test-icon" id="test-icon"></span><span class="test-msg" id="test-msg"></span></div>' +
            '</div>' +
            '<div class="modal-footer">' +
                '<button type="button" class="btn btn-success" onclick="App.testFromModal()"><i class="ti ti-plug-connected"></i> Test Connection</button>' +
                '<div class="modal-footer-right">' +
                    '<button type="button" class="btn" onclick="App.closeModal()">Cancel</button>' +
                    '<button type="button" class="btn btn-primary" onclick="App.saveConnection(\'' + (editId||'') + '\')"><i class="ti ti-device-floppy"></i> Save</button>' +
                '</div>' +
            '</div>';

        modal.onclick = function(e) { e.stopPropagation(); };
        this.onTypeChange();
        this.toggleAuth();
        document.getElementById('modal-overlay').classList.add('active');
        document.addEventListener('keydown', App._escHandler);
    },

    detectServers: function() {
        var hostInput = document.getElementById('conn-host');
        var datalist = document.getElementById('server-list');
        if (!datalist) return;
        datalist.innerHTML = '<option value="Detecting..."></option>';
        API.detectInstances().then(function(data) {
            datalist.innerHTML = '';
            (data.instances || []).forEach(function(inst) {
                var opt = document.createElement('option');
                opt.value = inst.name;
                datalist.appendChild(opt);
            });
            if (data.instances && data.instances.length > 0) {
                hostInput.value = data.instances[0].name;
                Toast.success('Found ' + data.instances.length + ' instance(s): ' + data.instances.map(function(i){return i.name;}).join(', '));
            } else {
                Toast.warning('No local instances detected');
            }
        }).catch(function(e) { Toast.error(e.message); });
    },

    onTypeChange: function() {
        var type = document.getElementById('conn-type').value;
        var auth = document.getElementById('auth-section');
        var creds = document.getElementById('creds-section');
        var server = document.getElementById('server-section');
        var encrypt = document.getElementById('encrypt-section');
        var trust = document.getElementById('trust-section');

        if (type === 'mssql') { auth.style.display = ''; App.toggleAuth(); }
        else { auth.style.display = 'none'; creds.style.display = ''; }
        if (type === 'sqlite') { server.style.display = 'none'; creds.style.display = 'none'; encrypt.style.display = 'none'; trust.style.display = 'none'; }
        else { server.style.display = ''; encrypt.style.display = ''; trust.style.display = ''; }
    },

    toggleAuth: function() {
        var creds = document.getElementById('creds-section');
        var auth = document.getElementById('conn-auth');
        if (auth && auth.value === 'windows') creds.style.display = 'none';
        else if (creds) creds.style.display = '';
    },

    closeModal: function() {
        document.getElementById('modal-overlay').classList.remove('active');
        document.removeEventListener('keydown', App._escHandler);
    },

    _escHandler: function(e) { if (e.key === 'Escape') App.closeModal(); },

    getModalData: function() {
        var type = document.getElementById('conn-type').value;
        var port = document.getElementById('conn-port').value.trim();
        var defaults = { mssql:1433, postgresql:5432, oracle:1521, mysql:3306, mariadb:3306 };
        var host = document.getElementById('conn-host').value || 'localhost';
        var name = document.getElementById('conn-name').value || host;
        return {
            type: type, host: host,
            port: port ? parseInt(port) : (defaults[type]||1433),
            username: document.getElementById('conn-user') ? document.getElementById('conn-user').value : '',
            password: document.getElementById('conn-pass') ? document.getElementById('conn-pass').value : '',
            database: document.getElementById('conn-db') ? document.getElementById('conn-db').value : '',
            name: name,
            options: {
                auth_type: document.getElementById('conn-auth') ? document.getElementById('conn-auth').value : 'sql_login',
                encrypt: document.getElementById('conn-encrypt') ? document.getElementById('conn-encrypt').value : 'optional',
                trust_server_certificate: document.getElementById('conn-trust') ? document.getElementById('conn-trust').checked : true
            }
        };
    },

    validateConnection: function() {
        var type = document.getElementById('conn-type').value;
        var host = document.getElementById('conn-host') ? document.getElementById('conn-host').value.trim() : '';
        var authType = document.getElementById('conn-auth') ? document.getElementById('conn-auth').value : 'sql_login';
        var user = document.getElementById('conn-user') ? document.getElementById('conn-user').value.trim() : '';
        var pass = document.getElementById('conn-pass') ? document.getElementById('conn-pass').value : '';

        // Server required (except SQLite)
        if (type !== 'sqlite' && !host) {
            Toast.warning('Server name is required');
            document.getElementById('conn-host').focus();
            return false;
        }

        // Username + Password required for SQL Auth (MSSQL)
        if (type === 'mssql' && authType === 'sql_login') {
            if (!user) {
                Toast.warning('Username is required for SQL Server Authentication');
                document.getElementById('conn-user').focus();
                return false;
            }
            if (!pass) {
                Toast.warning('Password is required for SQL Server Authentication');
                document.getElementById('conn-pass').focus();
                return false;
            }
        }

        // Username + Password required for non-Windows auth databases
        if (type !== 'mssql' && type !== 'sqlite') {
            if (!user) {
                Toast.warning('Username is required');
                document.getElementById('conn-user').focus();
                return false;
            }
            if (!pass) {
                Toast.warning('Password is required');
                document.getElementById('conn-pass').focus();
                return false;
            }
        }

        return true;
    },

    testFromModal: function() {
        if (!this.validateConnection()) return;

        var data = this.getModalData();
        var r = document.getElementById('test-result');
        var ico = document.getElementById('test-icon');
        var msg = document.getElementById('test-msg');
        r.className = 'test-result';
        API.testConnectionDirect(data).then(function(res) {
            r.className = res.success ? 'test-result success' : 'test-result error';
            ico.textContent = res.success ? '\u2713' : '\u2717';
            msg.textContent = res.message;
        }).catch(function(e) { r.className = 'test-result error'; ico.textContent = '\u2717'; msg.textContent = e.message; });
    },

    saveConnection: function(editId) {
        if (!this.validateConnection()) return;

        var self = this;
        var data = this.getModalData();
        var p;
        if (editId) { p = API.updateConnection(editId, data).then(function() { Toast.success('Updated'); }); }
        else { p = API.createConnection(data).then(function() { Toast.success('Saved'); }); }
        p.then(function() {
            self.closeModal();
            return self.loadConnections();
        }).then(function() { self.showDashboard(); }).catch(function(e) { Toast.error(e.message); });
    },

    /* ── Views ── */
    showQueryEditor: function(sql, database) {
        if (!this.state.activeConnectionId) { Toast.warning('Connect first'); return; }
        // If no database specified, use last active database (like SSMS)
        var db = database || this.state.activeDatabase || '';
        QueryEditor.openTab(this.state.activeConnectionId, db, sql || '');
    },
    showTableBrowser: function(db, schema, table) {
        if (!this.state.activeConnectionId) return;
        this.state.activeDatabase = db; this.state.activeSchema = schema;
        var connId = this.state.activeConnectionId;
        TabManager.addTab(schema + '.' + table, 'ti-table', 'data', function(panel, tabId) {
            panel.id = 'datagrid-' + tabId;
            DataGrid.initInPanel(connId, db, schema, table, panel);
        });
    },
    showTableDesigner: function(db, schema) {
        if (!this.state.activeConnectionId) { Toast.warning('Connect first'); return; }
        TableDesigner.init(this.state.activeConnectionId, db, schema);
    },
    updateRowCount: function(n) { var e = document.getElementById('status-rows'); if (e) e.textContent = n != null ? 'Rows: ' + formatNumber(n) : ''; },
    updateExecTime: function(ms) { var e = document.getElementById('status-time'); if (e) e.textContent = ms != null ? ms + 'ms' : ''; },

    logout: function() {
        fetch('/api/auth/logout', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' })
        .then(function() { window.location.href = '/login'; })
        .catch(function() { window.location.href = '/login'; });
    }
};

function esc(s) { var d = document.createElement('div'); d.textContent = s || ''; return d.innerHTML; }
function formatNumber(n) { return n ? n.toLocaleString() : '0'; }
document.addEventListener('DOMContentLoaded', function() { App.init(); });
