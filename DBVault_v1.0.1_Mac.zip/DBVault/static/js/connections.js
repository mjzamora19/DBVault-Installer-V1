/* Connections page logic - managed by App.js */
