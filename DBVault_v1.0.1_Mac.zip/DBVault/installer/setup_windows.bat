@echo off
title DBVault - Setup
color 0B
echo.
echo  ==========================================
echo   DBVault v1.0 - Windows Setup
echo   Database Management Tool
echo  ==========================================
echo.

:: Check if Python is installed
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo  Python is not installed.
    echo.
    echo  Please install Python 3.10+ from:
    echo  https://www.python.org/downloads/
    echo.
    echo  IMPORTANT: Check "Add Python to PATH" during install!
    echo.
    start https://www.python.org/downloads/
    pause
    exit /b
)

echo  [1/4] Python found:
python --version
echo.

echo  [2/4] Installing dependencies...
pip install flask flask-cors pyodbc psycopg2-binary cryptography --quiet
echo  Done.
echo.

echo  [3/4] Creating desktop shortcut...
set "SCRIPT_DIR=%~dp0.."
powershell -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut([System.IO.Path]::Combine([Environment]::GetFolderPath('Desktop'), 'DBVault.lnk')); $s.TargetPath = 'pythonw'; $s.Arguments = '\"' + '%SCRIPT_DIR%\launcher.py' + '\"'; $s.WorkingDirectory = '%SCRIPT_DIR%'; $s.Description = 'DBVault - Database Management Tool'; $s.Save()" >nul 2>&1
echo  Desktop shortcut created.
echo.

echo  [4/4] Creating Start Menu shortcut...
set "STARTMENU=%APPDATA%\Microsoft\Windows\Start Menu\Programs"
powershell -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut([System.IO.Path]::Combine('%STARTMENU%', 'DBVault.lnk')); $s.TargetPath = 'pythonw'; $s.Arguments = '\"' + '%SCRIPT_DIR%\launcher.py' + '\"'; $s.WorkingDirectory = '%SCRIPT_DIR%'; $s.Description = 'DBVault - Database Management Tool'; $s.Save()" >nul 2>&1
echo  Start Menu shortcut created.
echo.

echo  ==========================================
echo   Setup Complete!
echo  ==========================================
echo.
echo   Double-click "DBVault" on your desktop to start.
echo.
set /p LAUNCH="  Launch now? (Y/N): "
if /i "%LAUNCH%"=="Y" (
    cd /d "%SCRIPT_DIR%"
    start "" pythonw launcher.py
)
echo.
pause
