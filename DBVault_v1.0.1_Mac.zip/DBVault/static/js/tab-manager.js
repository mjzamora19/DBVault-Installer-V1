/* Tab Manager - SSMS-style tabs */

var TabManager = {
    tabs: [],
    activeTabId: null,
    nextId: 1,

    init: function() {
        var main = document.getElementById('main-content');
        main.innerHTML = '<div class="tab-bar" id="tab-bar"></div>' +
            '<div class="tab-content" id="tab-content"></div>';
    },

    ensureInit: function() {
        if (!document.getElementById('tab-bar')) this.init();
    },

    addTab: function(title, icon, type, initFn) {
        this.ensureInit();
        var id = 'tab-' + this.nextId++;
        var tab = { id: id, title: title, icon: icon, type: type };
        this.tabs.push(tab);

        // Create tab header
        var bar = document.getElementById('tab-bar');
        var header = document.createElement('div');
        header.className = 'tab-header';
        header.id = id + '-header';
        header.innerHTML = '<span class="tab-icon"><i class="ti ' + icon + '"></i></span>' +
            '<span class="tab-title">' + esc(title) + '</span>' +
            '<button class="tab-close" onclick="event.stopPropagation();TabManager.closeTab(\'' + id + '\')">&times;</button>';
        header.onclick = function() { TabManager.switchTab(id); };
        bar.appendChild(header);

        // Create tab panel
        var content = document.getElementById('tab-content');
        var panel = document.createElement('div');
        panel.className = 'tab-panel';
        panel.id = id + '-panel';
        panel.style.display = 'none';
        content.appendChild(panel);

        // Switch to new tab
        this.switchTab(id);

        // Initialize content
        if (initFn) initFn(panel, id);

        return id;
    },

    switchTab: function(id) {
        // Deactivate all
        var headers = document.querySelectorAll('.tab-header');
        var panels = document.querySelectorAll('.tab-panel');
        for (var i = 0; i < headers.length; i++) headers[i].classList.remove('active');
        for (var i = 0; i < panels.length; i++) panels[i].style.display = 'none';

        // Activate selected
        var h = document.getElementById(id + '-header');
        var p = document.getElementById(id + '-panel');
        if (h) h.classList.add('active');
        if (p) p.style.display = '';
        this.activeTabId = id;
    },

    closeTab: function(id) {
        var header = document.getElementById(id + '-header');
        var panel = document.getElementById(id + '-panel');
        if (header) header.remove();
        if (panel) panel.remove();

        // Remove from tabs array
        for (var i = 0; i < this.tabs.length; i++) {
            if (this.tabs[i].id === id) { this.tabs.splice(i, 1); break; }
        }

        // Switch to another tab or show dashboard
        if (this.tabs.length > 0) {
            this.switchTab(this.tabs[this.tabs.length - 1].id);
        } else {
            this.activeTabId = null;
            App.showDashboard();
        }
    },

    closeAll: function() {
        this.tabs = [];
        this.activeTabId = null;
        var bar = document.getElementById('tab-bar');
        var content = document.getElementById('tab-content');
        if (bar) bar.innerHTML = '';
        if (content) content.innerHTML = '';
    }
};
